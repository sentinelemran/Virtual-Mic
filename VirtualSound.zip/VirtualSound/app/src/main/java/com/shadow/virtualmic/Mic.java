package com.shadow.virtualmic;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuRemoteProcess;

/** Controller for the Injector process: launches it via root or Shizuku, and talks to it through files. */
public class Mic {
    public enum Mode { NONE, ROOT, SHIZUKU }

    public interface Callback { void onResult(boolean ok, String msg); }

    static final String CLASS = "com.shadow.virtualmic.Injector";
    static final Handler H = new Handler(Looper.getMainLooper());

    public static Mode mode = Mode.NONE;
    static Process rootProc;
    static ShizukuRemoteProcess shizukuProc;

    static File dir(Context c) {
        File f = c.getExternalFilesDir("mic");
        if (f == null) f = new File(c.getFilesDir(), "mic");
        f.mkdirs();
        return f;
    }

    static File cmdFile(Context c) { return new File(dir(c), "cmd"); }
    static File readyFile(Context c) { return new File(dir(c), "ready"); }
    static File logFile(Context c) { return new File(dir(c), "inject.log"); }
    static File pcmFile(Context c) { return new File(dir(c), "pcm_out.pcm"); }

    static String apkPath(Context c) { return c.getApplicationInfo().sourceDir; }

    public static boolean running() { return mode != Mode.NONE; }

    public static boolean shizukuAvailable() {
        try { return Shizuku.pingBinder(); } catch (Throwable e) { return false; }
    }

    public static boolean shizukuGranted() {
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; } catch (Throwable e) { return false; }
    }

    public static void requestShizukuPermission(int code) {
        try { Shizuku.requestPermission(code); } catch (Throwable e) { }
    }

    public static void startRoot(final Context c, final Callback cb) {
        stop(c);
        try {
            readyFile(c).delete();
            logFile(c).delete();
            String cmd = "CLASSPATH=" + apkPath(c) + " nohup app_process /system/bin " + CLASS + " "
                    + dir(c).getAbsolutePath() + " > " + dir(c).getAbsolutePath() + "/stdout.log 2>&1 &\n";
            ProcessBuilder pb = new ProcessBuilder("su");
            pb.redirectErrorStream(true);
            Process p = pb.start();
            OutputStream os = p.getOutputStream();
            os.write(cmd.getBytes("UTF-8"));
            os.write("exit\n".getBytes("UTF-8"));
            os.flush();
            os.close();
            rootProc = p;
            mode = Mode.ROOT;
            waitReady(c, cb);
        } catch (Throwable e) {
            mode = Mode.NONE;
            cb.onResult(false, "Root launch failed: " + e);
        }
    }

    public static void startShizuku(final Context c, final Callback cb) {
        stop(c);
        try {
            if (!shizukuAvailable()) { cb.onResult(false, "Shizuku is not running. Open the Shizuku app and start it."); return; }
            if (!shizukuGranted()) { cb.onResult(false, "Shizuku permission not granted yet."); return; }
            readyFile(c).delete();
            logFile(c).delete();
            String[] cmd = {"sh", "-c",
                    "CLASSPATH=" + apkPath(c) + " exec app_process /system/bin " + CLASS + " " + dir(c).getAbsolutePath()};
            java.lang.reflect.Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            shizukuProc = (ShizukuRemoteProcess) m.invoke(null, (Object) cmd, null, null);
            mode = Mode.SHIZUKU;
            waitReady(c, cb);
        } catch (Throwable e) {
            mode = Mode.NONE;
            cb.onResult(false, "Shizuku launch failed: " + e);
        }
    }

    static void waitReady(final Context c, final Callback cb) {
        new Thread(new Runnable() {
            public void run() {
                for (int i = 0; i < 60; i++) {
                    if (readyFile(c).exists()) { post(cb, true, "Injection is ON"); return; }
                    try { Thread.sleep(100); } catch (Throwable e) { }
                }
                mode = Mode.NONE;
                post(cb, false, "Timed out. Check Help > last inject.log");
            }
        }).start();
    }

    static void post(final Callback cb, final boolean ok, final String msg) {
        H.post(new Runnable() { public void run() { if (cb != null) cb.onResult(ok, msg); } });
    }

    public static void stop(Context c) {
        try {
            File f = cmdFile(c);
            java.io.FileWriter w = new java.io.FileWriter(f, false);
            w.write("quit\n");
            w.close();
        } catch (Throwable e) { }
        try { if (rootProc != null) { OutputStream os = rootProc.getOutputStream(); os.write("exit\n".getBytes()); os.flush(); } } catch (Throwable e) { }
        try {
            ProcessBuilder pb = new ProcessBuilder("su", "-c", "pkill -f " + CLASS);
            pb.start();
        } catch (Throwable e) { }
        try { if (shizukuProc != null) shizukuProc.destroy(); } catch (Throwable e) { }
        rootProc = null;
        shizukuProc = null;
        mode = Mode.NONE;
    }

    /** data16k: 16kHz mono PCM16. Resampled to 48kHz before being handed to the injector. */
    public static void play(Context c, short[] data16k, float gain) {
        if (mode == Mode.NONE) return;
        try {
            short[] data48k = resample3x(data16k, gain);
            byte[] bytes = new byte[data48k.length * 2];
            java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(data48k);
            File f = pcmFile(c);
            FileOutputStream o = new FileOutputStream(f);
            o.write(bytes);
            o.close();
            java.io.FileWriter w = new java.io.FileWriter(cmdFile(c), false);
            w.write("play:" + f.getName() + "\n");
            w.close();
        } catch (Throwable e) { }
    }

    public static void stopSound(Context c) {
        if (mode == Mode.NONE) return;
        try {
            java.io.FileWriter w = new java.io.FileWriter(cmdFile(c), false);
            w.write("stop\n");
            w.close();
        } catch (Throwable e) { }
    }

    static short[] resample3x(short[] in, float gain) {
        short[] out = new short[in.length * 3];
        for (int i = 0; i < in.length; i++) {
            int v = (int) (in[i] * gain);
            short s = (short) Math.max(-32768, Math.min(32767, v));
            out[i * 3] = s;
            out[i * 3 + 1] = s;
            out[i * 3 + 2] = s;
        }
        return out;
    }

    public static String lastLog(Context c) {
        try {
            File f = logFile(c);
            if (!f.exists()) return "(no inject.log yet)";
            byte[] b = new byte[(int) f.length()];
            java.io.DataInputStream in = new java.io.DataInputStream(new java.io.FileInputStream(f));
            in.readFully(b);
            in.close();
            String s = new String(b, "UTF-8");
            return s.length() > 15000 ? s.substring(s.length() - 15000) : s;
        } catch (Throwable e) { return "Could not read log: " + e; }
    }
}
