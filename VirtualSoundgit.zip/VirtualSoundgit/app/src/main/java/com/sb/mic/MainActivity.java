package com.sb.mic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;

public class MainActivity extends Activity implements SoundPanel.Host {
    SoundPanel panel;
    boolean suppress;
    Uri pAudio, pIcon;
    TextView aLbl, iLbl;

    int dp(float v) { return SoundPanel.dp(this, v); }

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(SoundPanel.BG);
        getWindow().setNavigationBarColor(SoundPanel.BG);
        Store.ensureBuiltins(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SoundPanel.BG);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        SpannableString ss = new SpannableString("VIRTUAL SOUND");
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C1), 0, 8, 0);
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C2), 8, 13, 0);
        title.setText(ss);
        title.setTextSize(20);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        title.setShadowLayer(12, 0, 0, SoundPanel.C1);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(circle("+", new View.OnClickListener() { public void onClick(View v) { importFolder(); } }));
        head.addView(circle("\u2014", new View.OnClickListener() { public void onClick(View v) { minimize(); } }));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.bottomMargin = dp(12);
        root.addView(head, hl);

        panel = new SoundPanel(this, this, true);
        root.addView(panel, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        askOverlay();
    }

    View circle(String t, View.OnClickListener l) {
        TextView v = SoundPanel.tv(this, t, 22, SoundPanel.C1);
        v.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0);
        g.setStroke(dp(1.5f), SoundPanel.C1);
        v.setBackground(g);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(42), dp(42));
        p.leftMargin = dp(8);
        v.setLayoutParams(p);
        return v;
    }

    boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    void launch(Intent i, int code) {
        suppress = true;
        startActivityForResult(i, code);
    }

    void askOverlay() {
        if (canOverlay()) return;
        new AlertDialog.Builder(this).setTitle("Permission needed")
                .setMessage("Allow \"Display over other apps\" so Virtual Sound can float over your game when minimized.")
                .setPositiveButton("Allow", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 9);
                    }
                }).setNegativeButton("Later", null).show();
    }

    void startOverlay() {
        if (canOverlay()) startService(new Intent(this, OverlayService.class));
    }

    void minimize() {
        if (!canOverlay()) { askOverlay(); return; }
        startOverlay();
        moveTaskToBack(true);
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!suppress) startOverlay();
    }

    @Override protected void onResume() {
        super.onResume();
        suppress = false;
        stopService(new Intent(this, OverlayService.class));
        if (panel != null) panel.refresh();
    }

    void toast(final String s) {
        runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show(); } });
    }

    void importFolder() {
        launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2);
    }

    Intent pick(String type, String[] mimes) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType(type);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (mimes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
        return i;
    }

    public void addSound() {
        pAudio = null;
        pIcon = null;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(20), dp(10), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine();
        v.addView(name);
        Button ab = new Button(this);
        ab.setAllCaps(false);
        ab.setText("Audio:  Browse");
        ab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) { launch(pick("*/*", new String[]{"audio/*", "video/*"}), 1); }
        });
        v.addView(ab);
        aLbl = new TextView(this);
        aLbl.setText("No file selected");
        v.addView(aLbl);
        Button ib = new Button(this);
        ib.setAllCaps(false);
        ib.setText("Icon / Image:  Browse");
        ib.setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) { launch(pick("image/*", null), 3); }
        });
        v.addView(ib);
        iLbl = new TextView(this);
        iLbl.setText("Optional");
        v.addView(iLbl);

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add sound").setView(v)
                .setPositiveButton("Save", null).setNegativeButton("Cancel", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            public void onClick(View x) {
                if (pAudio == null) { toast("Choose an audio file first"); return; }
                save(name.getText().toString().trim());
                dlg.dismiss();
            }
        });
    }

    void save(final String nm) {
        final Uri a = pAudio, ic = pIcon;
        toast("Saving...");
        new Thread(new Runnable() {
            public void run() {
                try {
                    String base = Store.clean(nm.isEmpty() ? Store.displayName(MainActivity.this, a) : nm, nm.isEmpty());
                    short[] s = Store.decode(MainActivity.this, a);
                    File dir = Store.soundsDir(MainActivity.this);
                    Store.savePcm(dir, base, s, System.currentTimeMillis());
                    if (ic != null) Store.saveIcon(MainActivity.this, ic, new File(dir, base + ".png"));
                    runOnUiThread(new Runnable() { public void run() { panel.refresh(); } });
                    toast("Added");
                } catch (Exception e) { toast("Failed: " + e.getMessage()); }
            }
        }).start();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rs != RESULT_OK || d == null || d.getData() == null) return;
        final Uri u = d.getData();
        if (rq == 1) {
            pAudio = u;
            if (aLbl != null) aLbl.setText(Store.displayName(this, u));
        } else if (rq == 3) {
            pIcon = u;
            if (iLbl != null) iLbl.setText(Store.displayName(this, u));
        } else if (rq == 2) {
            toast("Importing folder...");
            new Thread(new Runnable() {
                public void run() {
                    final int n = Store.importTree(MainActivity.this, u);
                    runOnUiThread(new Runnable() { public void run() { panel.refresh(); } });
                    toast(n > 0 ? "Imported " + n + " sounds" : "No audio files found in that folder");
                }
            }).start();
        }
    }
}
