package com.sb.mic;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Floating bubble / mini window that stays over the game. */
public class OverlayService extends Service {
    WindowManager wm;
    FrameLayout root;
    TextView bubble;
    LinearLayout box;
    SoundPanel panel;
    WindowManager.LayoutParams lp;

    public IBinder onBind(Intent i) { return null; }

    public int onStartCommand(Intent i, int f, int id) {
        if (root == null) build();
        return START_NOT_STICKY;
    }

    class Drag implements View.OnTouchListener {
        int sx, sy;
        float tx, ty;
        boolean moved;
        final Runnable tap;
        Drag(Runnable t) { tap = t; }
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                    if (moved) {
                        lp.x = sx + (int) dx;
                        lp.y = sy + (int) dy;
                        wm.updateViewLayout(root, lp);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved && tap != null) tap.run();
                    return true;
            }
            return false;
        }
    }

    TextView smallBtn(String t, View.OnClickListener l) {
        TextView b = SoundPanel.tv(this, t, 12, SoundPanel.C1);
        b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        int p = SoundPanel.dp(this, 8);
        b.setPadding(p, p / 2, p, p / 2);
        b.setBackground(SoundPanel.rect(this, 0, SoundPanel.C1, 10));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams q = new LinearLayout.LayoutParams(-2, -2);
        q.leftMargin = SoundPanel.dp(this, 6);
        b.setLayoutParams(q);
        return b;
    }

    void build() {
        final Context c = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(-2, -2, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = SoundPanel.dp(c, 10);
        lp.y = SoundPanel.dp(c, 150);

        root = new FrameLayout(c);

        bubble = SoundPanel.tv(c, "\uD83C\uDFB5", 24, SoundPanel.TXT);
        bubble.setGravity(Gravity.CENTER);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(0xEE12121E);
        oval.setStroke(SoundPanel.dp(c, 2), SoundPanel.C1);
        bubble.setBackground(oval);
        bubble.setOnTouchListener(new Drag(new Runnable() { public void run() { expand(); } }));
        root.addView(bubble, new FrameLayout.LayoutParams(SoundPanel.dp(c, 56), SoundPanel.dp(c, 56)));

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = SoundPanel.dp(c, 10);
        box.setPadding(p, p, p, p);
        box.setBackground(SoundPanel.rect(c, 0xF207070D, SoundPanel.C1, 18));
        box.setVisibility(View.GONE);

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = SoundPanel.tv(c, "VIRTUAL SOUND", 13, SoundPanel.C1);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, p / 2, 0, p / 2);
        title.setOnTouchListener(new Drag(null));
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(smallBtn("\u2014", new View.OnClickListener() { public void onClick(View v) { collapse(); } }));
        head.addView(smallBtn("Open", new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(c, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
            }
        }));
        head.addView(smallBtn("X", new View.OnClickListener() { public void onClick(View v) { stopSelf(); } }));
        box.addView(head, new LinearLayout.LayoutParams(-1, -2));

        panel = new SoundPanel(c, null, false);
        box.addView(panel, new LinearLayout.LayoutParams(SoundPanel.dp(c, 280), SoundPanel.dp(c, 340)));
        root.addView(box, new FrameLayout.LayoutParams(-2, -2));

        wm.addView(root, lp);
    }

    void expand() {
        bubble.setVisibility(View.GONE);
        box.setVisibility(View.VISIBLE);
        panel.refresh();
    }

    void collapse() {
        box.setVisibility(View.GONE);
        bubble.setVisibility(View.VISIBLE);
    }

    public void onDestroy() {
        super.onDestroy();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception e) { }
            root = null;
        }
    }
}
