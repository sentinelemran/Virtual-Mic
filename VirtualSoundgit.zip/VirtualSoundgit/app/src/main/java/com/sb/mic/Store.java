package com.sb.mic;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

/** Storage: sounds are 16kHz mono PCM files. filesDir/sounds/*.pcm and filesDir/folders/NAME/*.pcm */
public class Store {
    public static class Item {
        public String name;
        public File pcm, icon, dir;
        public boolean folder;
    }

    static File soundsDir(Context c) { File f = new File(c.getFilesDir(), "sounds"); f.mkdirs(); return f; }
    static File foldersDir(Context c) { File f = new File(c.getFilesDir(), "folders"); f.mkdirs(); return f; }

    static String clean(String s, boolean stripExt) {
        if (s == null) s = "";
        if (stripExt) s = s.replaceAll("\\.[^.]*$", "");
        s = s.replaceAll("[^\\p{L}\\p{N} _-]", "_").trim();
        if (s.isEmpty()) s = "sound";
        return s.length() > 24 ? s.substring(0, 24) : s;
    }

    static List<Item> sounds(Context c, File dir) {
        List<Item> r = new ArrayList<>();
        File[] fs = dir.listFiles();
        if (fs == null) return r;
        Arrays.sort(fs, new Comparator<File>() {
            public int compare(File a, File b) {
                int d = Long.compare(a.lastModified(), b.lastModified());
                return d != 0 ? d : a.getName().compareTo(b.getName());
            }
        });
        for (File f : fs) {
            String n = f.getName();
            if (!n.endsWith(".pcm")) continue;
            Item it = new Item();
            it.name = n.substring(0, n.length() - 4);
            it.pcm = f;
            File ic = new File(dir, it.name + ".png");
            it.icon = ic.exists() ? ic : null;
            r.add(it);
        }
        return r;
    }

    static List<Item> folderItems(Context c) {
        List<Item> r = new ArrayList<>();
        File[] fs = foldersDir(c).listFiles();
        if (fs == null) return r;
        Arrays.sort(fs);
        for (File f : fs) {
            if (!f.isDirectory()) continue;
            Item it = new Item();
            it.name = f.getName();
            it.dir = f;
            it.folder = true;
            r.add(it);
        }
        return r;
    }

    static void delete(Item it) {
        if (it.folder) deleteRec(it.dir);
        else {
            it.pcm.delete();
            if (it.icon != null) it.icon.delete();
        }
    }

    static void deleteRec(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File x : k) deleteRec(x);
        f.delete();
    }

    static byte[] read(File f) {
        try {
            byte[] b = new byte[(int) f.length()];
            DataInputStream in = new DataInputStream(new FileInputStream(f));
            in.readFully(b);
            in.close();
            return b;
        } catch (Exception e) { return null; }
    }

    static void savePcm(File dir, String name, short[] s, long time) {
        try {
            ByteBuffer bb = ByteBuffer.allocate(s.length * 2).order(ByteOrder.LITTLE_ENDIAN);
            bb.asShortBuffer().put(s);
            File f = new File(dir, name + ".pcm");
            FileOutputStream o = new FileOutputStream(f);
            o.write(bb.array());
            o.close();
            f.setLastModified(time);
        } catch (Exception e) { }
    }

    static void ensureBuiltins(Context c) {
        SharedPreferences sp = c.getSharedPreferences("p", 0);
        if (sp.getBoolean("bi", false)) return;
        String[] n = {"Air Horn", "Bruh", "Sad Horn", "Explosion", "Laugh", "Drum"};
        short[][] d = {Synth.airHorn(), Synth.bruh(), Synth.sadHorn(), Synth.explosion(), Synth.laugh(), Synth.drum()};
        long t = System.currentTimeMillis() - 100000;
        for (int i = 0; i < n.length; i++) savePcm(soundsDir(c), n[i], d[i], t + i * 1000L);
        sp.edit().putBoolean("bi", true).apply();
    }

    static String displayName(Context c, Uri u) {
        String name = "sound";
        try {
            Cursor cu = c.getContentResolver().query(u, null, null, null, null);
            if (cu != null) {
                if (cu.moveToFirst()) {
                    int ix = cu.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (ix >= 0) name = cu.getString(ix);
                }
                cu.close();
            }
        } catch (Exception e) { }
        return name;
    }

    static void saveIcon(Context c, Uri u, File dest) throws Exception {
        InputStream in = c.getContentResolver().openInputStream(u);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(in, null, o);
        in.close();
        int ss = 1;
        while (o.outWidth / ss > 256) ss *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = ss;
        in = c.getContentResolver().openInputStream(u);
        Bitmap b = BitmapFactory.decodeStream(in, null, o2);
        in.close();
        int m = Math.min(b.getWidth(), b.getHeight());
        Bitmap sq = Bitmap.createBitmap(b, (b.getWidth() - m) / 2, (b.getHeight() - m) / 2, m, m);
        Bitmap sc = Bitmap.createScaledBitmap(sq, 128, 128, true);
        FileOutputStream fo = new FileOutputStream(dest);
        sc.compress(Bitmap.CompressFormat.PNG, 100, fo);
        fo.close();
    }

    static boolean isAudio(String nm, String mt) {
        if (mt != null && (mt.startsWith("audio/") || mt.startsWith("video/"))) return true;
        return nm != null && nm.toLowerCase().matches(".*\\.(mp3|wav|ogg|opus|m4a|aac|amr|3gp|flac|wma|mp4|webm|mkv)$");
    }

    /** Import every audio file inside a folder picked with ACTION_OPEN_DOCUMENT_TREE. */
    static int importTree(Context c, Uri tree) {
        ContentResolver cr = c.getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        String fname = "Folder";
        try {
            Cursor nc = cr.query(DocumentsContract.buildDocumentUriUsingTree(tree, rootId),
                    new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (nc != null) {
                if (nc.moveToFirst()) fname = nc.getString(0);
                nc.close();
            }
        } catch (Exception e) { }
        File dir = new File(foldersDir(c), clean(fname, false));
        dir.mkdirs();
        int n = 0;
        long t = System.currentTimeMillis();
        try {
            Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId);
            Cursor cu = cr.query(kids, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
            if (cu != null) {
                while (cu.moveToNext()) {
                    String id = cu.getString(0), nm = cu.getString(1), mt = cu.getString(2);
                    if (!isAudio(nm, mt)) continue;
                    try {
                        short[] s = decode(c, DocumentsContract.buildDocumentUriUsingTree(tree, id));
                        savePcm(dir, clean(nm, true), s, t + n * 10L);
                        n++;
                    } catch (Exception e) { }
                }
                cu.close();
            }
        } catch (Exception e) { }
        if (n == 0) dir.delete();
        return n;
    }

    /** Decode any audio/video file to 16kHz mono PCM (max 15 seconds). */
    static short[] decode(Context c, Uri u) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(c, u, null);
        int t = -1;
        MediaFormat f = null;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat tf = ex.getTrackFormat(i);
            if (tf.getString(MediaFormat.KEY_MIME).startsWith("audio/")) { t = i; f = tf; break; }
        }
        if (t < 0) throw new Exception("no audio track");
        ex.selectTrack(t);
        MediaCodec mc = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME));
        mc.configure(f, null, null, 0);
        mc.start();
        int rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE);
        int ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        boolean inDone = false, outDone = false;
        while (!outDone && bos.size() < 15L * rate * ch * 2) {
            if (!inDone) {
                int ii = mc.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    ByteBuffer ib = mc.getInputBuffer(ii);
                    int n = ex.readSampleData(ib, 0);
                    if (n < 0) { mc.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                    else { mc.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0); ex.advance(); }
                }
            }
            int oi = mc.dequeueOutputBuffer(bi, 10000);
            if (oi >= 0) {
                ByteBuffer ob = mc.getOutputBuffer(oi);
                byte[] chunk = new byte[bi.size];
                ob.position(bi.offset);
                ob.get(chunk);
                bos.write(chunk, 0, chunk.length);
                mc.releaseOutputBuffer(oi, false);
                if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat of = mc.getOutputFormat();
                rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            }
        }
        mc.stop();
        mc.release();
        ex.release();
        byte[] raw = bos.toByteArray();
        int frames = raw.length / 2 / ch;
        double step = rate / 16000.0;
        int outN = (int) (frames / step);
        short[] out = new short[outN];
        ByteBuffer bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < outN; i++) {
            int fi = (int) (i * step), s = 0;
            for (int k = 0; k < ch; k++) s += bb.getShort((fi * ch + k) * 2);
            out[i] = (short) (s / ch);
        }
        return out;
    }
}
