Virtual Sound (rooted phones, LSPosed)
1. Open this folder in Android Studio (File > Open), wait for Gradle sync.
2. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
3. Install on the phone, open it, allow "Display over other apps".
4. LSPosed > Modules > enable Virtual Sound, scope: Free Fire (and Free Fire MAX). Force stop the game.
5. In game, enable voice chat / mic, press a sound in Virtual Sound.
