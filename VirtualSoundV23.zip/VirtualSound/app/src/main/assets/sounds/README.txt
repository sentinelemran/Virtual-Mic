Drop your own audio files (mp3/wav/m4a/ogg...) in this folder to replace the default sounds. Each file becomes one default sound button, named after the file.
