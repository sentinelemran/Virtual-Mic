package com.shadow.virtualmic;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Floating bubble / mini window that stays over the game. */
public class OverlayService extends Service {
    WindowManager wm;
    FrameLayout root;
    android.widget.ImageView bubble;
    LinearLayout box;
    SoundPanel panel;
    WindowManager.LayoutParams lp;

    public IBinder onBind(Intent i) { return null; }

    public int onStartCommand(Intent i, int f, int id) {
        if (root == null) build();
        return START_NOT_STICKY;
    }

    View closeView;
    WindowManager.LayoutParams closeLp;

    void showCloseTarget() {
        if (closeView != null) return;
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        TextView cv = new TextView(this);
        cv.setText("\u2715");
        cv.setTextSize(22);
        cv.setTextColor(SoundPanel.TXT);
        cv.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xCC1A1A2E);
        g.setStroke(SoundPanel.dp(this, 2), SoundPanel.RED);
        cv.setBackground(g);
        int sz = SoundPanel.dp(this, 64);
        closeLp = new WindowManager.LayoutParams(sz, sz,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        closeLp.gravity = Gravity.TOP | Gravity.START;
        closeLp.x = dm.widthPixels / 2 - sz / 2;
        closeLp.y = dm.heightPixels - sz - SoundPanel.dp(this, 90);
        closeView = cv;
        try { wm.addView(closeView, closeLp); } catch (Throwable e) { closeView = null; }
    }

    void hideCloseTarget() {
        if (closeView == null) return;
        try { wm.removeView(closeView); } catch (Throwable e) { }
        closeView = null;
    }

    boolean nearClose(float rawX, float rawY) {
        if (closeLp == null) return false;
        float cx = closeLp.x + closeLp.width / 2f, cy = closeLp.y + closeLp.height / 2f;
        return Math.hypot(rawX - cx, rawY - cy) < SoundPanel.dp(this, 75);
    }

    void highlightClose(boolean near) {
        if (closeView == null) return;
        ((GradientDrawable) closeView.getBackground()).setColor(near ? 0xFFFF3B5C : 0xCC1A1A2E);
    }

    /** closable=true (the bubble only): shows a drag-down-to-close target while dragging,
     *  and removes the whole overlay if dropped on it. */
    class Drag implements View.OnTouchListener {
        int sx, sy;
        float tx, ty;
        boolean moved;
        final Runnable tap;
        final boolean closable;
        Drag(Runnable t) { this(t, false); }
        Drag(Runnable t, boolean closable) { tap = t; this.closable = closable; }
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); moved = false;
                    if (closable) showCloseTarget();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - tx, dy = e.getRawY() - ty;
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                    if (moved) {
                        lp.x = sx + (int) dx;
                        lp.y = sy + (int) dy;
                        wm.updateViewLayout(root, lp);
                    }
                    if (closable) highlightClose(nearClose(e.getRawX(), e.getRawY()));
                    return true;
                case MotionEvent.ACTION_UP:
                    if (closable) {
                        boolean drop = nearClose(e.getRawX(), e.getRawY());
                        hideCloseTarget();
                        if (drop) { stopSelf(); return true; }
                    }
                    if (!moved && tap != null) tap.run();
                    return true;
            }
            return false;
        }
    }

    TextView smallBtn(String t, View.OnClickListener l) {
        TextView b = SoundPanel.tv(this, t, 9, SoundPanel.C1);
        b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        int ph = SoundPanel.dp(this, 5), pv = SoundPanel.dp(this, 2);
        b.setPadding(ph, pv, ph, pv);
        b.setBackground(SoundPanel.rect(this, 0, SoundPanel.C1, 8));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams q = new LinearLayout.LayoutParams(-2, -2);
        q.leftMargin = SoundPanel.dp(this, 4);
        b.setLayoutParams(q);
        return b;
    }

    void build() {
        final Context c = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(-2, -2, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = SoundPanel.dp(c, 10);
        lp.y = SoundPanel.dp(c, 150);

        root = new FrameLayout(c);
        // Tapping anywhere in the game outside this small window collapses the
        // expanded panel back to just the bubble, instead of needing another tap
        // on the minimize/collapse button every time.
        root.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_OUTSIDE && box != null && box.getVisibility() == View.VISIBLE) {
                    collapse();
                }
                return false;
            }
        });

        bubble = new android.widget.ImageView(c);
        bubble.setImageResource(R.drawable.ic_logo);
        bubble.setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
        GradientDrawable oval = new GradientDrawable();
        oval.setShape(GradientDrawable.OVAL);
        oval.setColor(0xFF0B0B18);
        oval.setStroke(SoundPanel.dp(c, 2), SoundPanel.C1);
        bubble.setBackground(oval);
        bubble.setClipToOutline(true);
        bubble.setOnTouchListener(new Drag(new Runnable() { public void run() { expand(); } }, true));
        root.addView(bubble, new FrameLayout.LayoutParams(SoundPanel.dp(c, 56), SoundPanel.dp(c, 56)));

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = SoundPanel.dp(c, 10);
        box.setPadding(p, p, p, p);
        box.setBackground(SoundPanel.rect(c, 0xF207070D, SoundPanel.C1, 18));
        box.setVisibility(View.GONE);

        LinearLayout head = new LinearLayout(c);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = SoundPanel.tv(c, "VIRTUAL SOUND", 11, SoundPanel.C1);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, p / 2, 0, p / 2);
        title.setOnTouchListener(new Drag(null));
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(smallBtn("\u2014", new View.OnClickListener() { public void onClick(View v) { collapse(); } }));
        head.addView(smallBtn("Open", new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(c, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
            }
        }));
        head.addView(smallBtn("X", new View.OnClickListener() { public void onClick(View v) { stopSelf(); } }));
        box.addView(head, new LinearLayout.LayoutParams(-1, -2));

        panel = new SoundPanel(c, null, false, true);
        box.addView(panel, new LinearLayout.LayoutParams(SoundPanel.dp(c, 200), SoundPanel.dp(c, 250)));
        root.addView(box, new FrameLayout.LayoutParams(-2, -2));

        wm.addView(root, lp);
    }

    void expand() {
        bubble.setVisibility(View.GONE);
        box.setVisibility(View.VISIBLE);
        panel.refresh();
    }

    void collapse() {
        box.setVisibility(View.GONE);
        bubble.setVisibility(View.VISIBLE);
    }

    public void onDestroy() {
        super.onDestroy();
        if (root != null) {
            try { wm.removeView(root); } catch (Exception e) { }
            root = null;
        }
    }
}
