package com.shadow.virtualmic;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.content.Context;
import android.os.Looper;
import java.io.*;
import java.lang.reflect.*;

/**
 * Runs as a standalone "app_process" process, outside the app, with elevated
 * identity (root uid=0, or shell uid=2000 via Shizuku). It registers a system
 * AudioPolicy that intercepts microphone-attribute capture (the hidden
 * android.media.audiopolicy APIs) and exposes an AudioTrack: whatever we write
 * into that AudioTrack is delivered to other apps as "microphone audio".
 *
 * This uses only @SystemApi / hidden classes, accessed entirely through
 * reflection because the public SDK used to compile this file does not expose
 * them. Every step is logged to inject.log so a failure can be diagnosed from
 * the log alone.
 */
public class Injector {
    static PrintWriter log;

    public static void main(String[] args) {
        File dir = new File(args.length > 0 ? args[0] : "/sdcard");
        try {
            log = new PrintWriter(new FileWriter(new File(dir, "inject.log"), true), true);
        } catch (Throwable e) {
            return;
        }
        try {
            run(dir);
        } catch (Throwable t) {
            log("FATAL: " + t);
            for (StackTraceElement s : t.getStackTrace()) log("  at " + s);
        }
        log("Injector exiting");
        try { log.close(); } catch (Throwable e) { }
    }

    static void log(String s) {
        try { log.println(System.currentTimeMillis() + "  " + s); log.flush(); } catch (Throwable e) { }
    }

    static Context sysContext;
    static Object audioManager, audioPolicyObj;
    static AudioTrack track;

    static void run(File dir) throws Exception {
        Looper.prepareMainLooper();
        log("==== Injector start, dir=" + dir.getAbsolutePath() + " uid=" + android.os.Process.myUid());

        Class<?> atClass = Class.forName("android.app.ActivityThread");
        Object activityThread = atClass.getMethod("systemMain").invoke(null);
        Context raw = (Context) atClass.getMethod("getSystemContext").invoke(activityThread);
        log("system context ok: " + raw + " pkg=" + raw.getPackageName());

        Context shellCtx;
        try {
            shellCtx = raw.createPackageContext("com.android.shell", Context.CONTEXT_IGNORE_SECURITY);
            log("createPackageContext(com.android.shell) ok: " + shellCtx.getPackageName());
        } catch (Throwable e) {
            log("createPackageContext(shell) failed, using raw system context: " + e);
            shellCtx = raw;
        }
        sysContext = shellCtx;

        audioManager = sysContext.getSystemService(Context.AUDIO_SERVICE);
        log("audio manager = " + audioManager);

        setup();

        File readyF = new File(dir, "ready");
        try (FileWriter w = new FileWriter(readyF)) { w.write("1"); }
        log("READY");

        File cmdFile = new File(dir, "cmd");
        long lastMod = -1;
        while (true) {
            Thread.sleep(60);
            if (!cmdFile.exists()) continue;
            long m = cmdFile.lastModified();
            if (m == lastMod) continue;
            lastMod = m;
            String content;
            try { content = readAll(cmdFile); } catch (Throwable e) { continue; }
            boolean quit = false;
            for (String ln : content.split("\n")) {
                ln = ln.trim();
                if (ln.isEmpty()) continue;
                log("cmd: " + ln);
                if (ln.equals("quit")) { quit = true; continue; }
                try { handle(ln, dir); } catch (Throwable e) { log("handle failed: " + e); }
            }
            if (quit) break;
        }
        teardown();
    }

    static void handle(String ln, File dir) throws Exception {
        if (ln.equals("stop")) {
            if (track != null) { try { track.stop(); } catch (Throwable e) { } }
            return;
        }
        if (ln.startsWith("play:")) {
            File f = new File(dir, ln.substring(5).trim());
            byte[] data = readBytes(f);
            if (track == null) throw new IllegalStateException("track not ready");
            try { track.stop(); } catch (Throwable e) { }
            track.play();
            int off = 0;
            while (off < data.length) {
                int n = track.write(data, off, Math.min(4096, data.length - off));
                if (n <= 0) break;
                off += n;
            }
            log("wrote " + off + " / " + data.length + " bytes");
        }
    }

    // ---- hidden-API setup ----

    static void setup() throws Exception {
        Class<?> RuleCls = Class.forName("android.media.audiopolicy.AudioMixingRule");
        Class<?> RuleBuilderCls = Class.forName("android.media.audiopolicy.AudioMixingRule$Builder");
        Object ruleBuilder = RuleBuilderCls.getConstructor().newInstance();

        int RULE_MATCH = RuleCls.getField("RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET").getInt(null);
        log("RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET=" + RULE_MATCH);

        Method setCapturePreset = AudioAttributes.Builder.class.getMethod("setCapturePreset", int.class);
        Method addMixRule = findMethod(RuleBuilderCls, "addMixRule", new Class<?>[]{int.class, Object.class});

        int[] presets = {
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC,
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.CAMCORDER,
                MediaRecorder.AudioSource.DEFAULT
        };
        for (int preset : presets) {
            AudioAttributes.Builder ab = new AudioAttributes.Builder();
            setCapturePreset.invoke(ab, preset);
            AudioAttributes attrs = ab.build();
            addMixRule.invoke(ruleBuilder, RULE_MATCH, attrs);
            log("rule added for preset " + preset);
        }
        Object mixingRule = RuleBuilderCls.getMethod("build").invoke(ruleBuilder);

        Class<?> MixCls = Class.forName("android.media.audiopolicy.AudioMix");
        Class<?> MixBuilderCls = Class.forName("android.media.audiopolicy.AudioMix$Builder");
        Object mixBuilder = MixBuilderCls.getConstructor(RuleCls).newInstance(mixingRule);

        AudioFormat format = new AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build();
        MixBuilderCls.getMethod("setFormat", AudioFormat.class).invoke(mixBuilder, format);

        int ROUTE_LOOP_BACK = MixCls.getField("ROUTE_FLAG_LOOP_BACK").getInt(null);
        MixBuilderCls.getMethod("setRouteFlags", int.class).invoke(mixBuilder, ROUTE_LOOP_BACK);
        log("route flags = " + ROUTE_LOOP_BACK + " (LOOP_BACK only, for capture injection)");

        Object audioMix = MixBuilderCls.getMethod("build").invoke(mixBuilder);

        Class<?> PolicyCls = Class.forName("android.media.audiopolicy.AudioPolicy");
        Class<?> PolicyBuilderCls = Class.forName("android.media.audiopolicy.AudioPolicy$Builder");
        Object polBuilder = PolicyBuilderCls.getConstructor(android.content.Context.class).newInstance(sysContext);
        PolicyBuilderCls.getMethod("addMix", MixCls).invoke(polBuilder, audioMix);
        try {
            PolicyBuilderCls.getMethod("setLooper", Looper.class).invoke(polBuilder, Looper.myLooper());
            log("setLooper ok");
        } catch (Throwable e) { log("setLooper not applied: " + e); }
        Object policy = PolicyBuilderCls.getMethod("build").invoke(polBuilder);
        log("policy built: " + policy);

        Method registerAudioPolicy = audioManager.getClass().getMethod("registerAudioPolicy", PolicyCls);
        Object regResult = registerAudioPolicy.invoke(audioManager, policy);
        log("registerAudioPolicy -> " + regResult);
        if (regResult instanceof Integer && (Integer) regResult != 0) {
            log("---- logcat around failure ----");
            captureLogcat();
            throw new RuntimeException("registerAudioPolicy failed, code=" + regResult);
        }

        Method createSrc = PolicyCls.getMethod("createAudioTrackSource", MixCls);
        Object t = createSrc.invoke(policy, audioMix);
        log("createAudioTrackSource -> " + t);
        if (!(t instanceof AudioTrack)) throw new RuntimeException("createAudioTrackSource did not return an AudioTrack");
        track = (AudioTrack) t;
        audioPolicyObj = policy;
    }

    static void teardown() {
        try { if (track != null) { track.stop(); track.release(); } } catch (Throwable e) { }
        try {
            if (audioPolicyObj != null) {
                Class<?> PolicyCls = Class.forName("android.media.audiopolicy.AudioPolicy");
                audioManager.getClass().getMethod("unregisterAudioPolicy", PolicyCls).invoke(audioManager, audioPolicyObj);
                log("unregisterAudioPolicy done");
            }
        } catch (Throwable e) { log("teardown unregister failed: " + e); }
    }

    // ---- reflection helpers ----

    static Method findMethod(Class<?> c, String name, Class<?>[] params) {
        try { return c.getMethod(name, params); } catch (Throwable e) { }
        log("looking for " + name + " on " + c + " ; declared methods:");
        for (Method m : c.getDeclaredMethods()) {
            log("   " + m);
            if (m.getName().equals(name)) { m.setAccessible(true); return m; }
        }
        throw new RuntimeException("method " + name + " not found on " + c);
    }

    static void captureLogcat() {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-t", "300"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String ln;
            while ((ln = r.readLine()) != null) {
                String low = ln.toLowerCase();
                if (low.contains("audiopolicy") || low.contains("audioflinger") || low.contains("submix")
                        || low.contains("audioservice") || low.contains("virtualmic") || low.contains("permission")) {
                    log("  LC: " + ln);
                }
            }
            r.close();
        } catch (Throwable e) {
            log("captureLogcat failed: " + e);
        }
    }

    static void dumpApi() {
        try {
            log("-- AudioMixingRule.Builder methods --");
            for (Method m : Class.forName("android.media.audiopolicy.AudioMixingRule$Builder").getMethods()) log("  " + m);
            log("-- AudioMix.Builder methods --");
            for (Method m : Class.forName("android.media.audiopolicy.AudioMix$Builder").getMethods()) log("  " + m);
            log("-- AudioMix constants --");
            for (Field f : Class.forName("android.media.audiopolicy.AudioMix").getFields()) {
                try { log("  " + f + " = " + f.get(null)); } catch (Throwable e) { log("  " + f); }
            }
            log("-- AudioPolicy.Builder methods --");
            for (Method m : Class.forName("android.media.audiopolicy.AudioPolicy$Builder").getMethods()) log("  " + m);
            log("-- AudioPolicy methods --");
            for (Method m : Class.forName("android.media.audiopolicy.AudioPolicy").getMethods()) log("  " + m);
        } catch (Throwable e) {
            log("dumpApi failed: " + e);
        }
    }

    static String readAll(File f) throws IOException {
        byte[] b = readBytes(f);
        return new String(b, "UTF-8");
    }

    static byte[] readBytes(File f) throws IOException {
        byte[] b = new byte[(int) f.length()];
        DataInputStream in = new DataInputStream(new FileInputStream(f));
        in.readFully(b);
        in.close();
        return b;
    }
}
