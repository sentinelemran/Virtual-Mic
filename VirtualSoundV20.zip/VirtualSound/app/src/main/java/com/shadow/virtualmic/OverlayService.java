package com.shadow.virtualmic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Floating bubble / mini window that stays over the game. */
public class OverlayService extends Service {
    WindowManager wm;
    FrameLayout root;
    ImageView bubble;
    LinearLayout box;
    SoundPanel panel;
    WindowManager.LayoutParams lp;

    public IBinder onBind(Intent i) { return null; }

    public int onStartCommand(Intent i, int f, int id) {
        if (root == null) build();
        startForeground(1, getNotification());
        return START_NOT_STICKY;
    }

    private Notification getNotification() {
        String channelId = "virtual_mic_channel";
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Virtual Mic Service", NotificationManager.IMPORTANCE_LOW);
            manager.createNotificationChannel(channel);
        }
        Notification.Builder builder = new Notification.Builder(this, channelId)
                .setContentTitle("Virtual Sound")
                .setContentText("Service is running")
                .setSmallIcon(R.drawable.ic_fg);
        return builder.build();
    }

    class Drag implements View.OnTouchListener {
        int sx, sy;
        float tx, ty;
        boolean moved;
        Runnable tap;
        Drag(Runnable t) { tap = t; }
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    sx = (int) e.getRawX(); sy = (int) e.getRawY();
                    tx = v.getX() - sx; ty = v.getY() - sy;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - sx) > 10 || Math.abs(e.getRawY() - sy) > 10) moved = true;
                    v.setX(Math.max(-200, Math.min(wm.getDefaultDisplay().getWidth() - v.getWidth() + 200, e.getRawX() + tx)));
                    v.setY(Math.max(-200, Math.min(wm.getDefaultDisplay().getHeight() - v.getHeight() + 200, e.getRawY() + ty)));
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved && tap != null) tap.run();
                    return true;
            }
            return false;
        }
    }

    void build() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        root = new FrameLayout(this);
        bubble = new ImageView(this);
        Drawable d = getDrawable(R.drawable.ic_logo);
        bubble.setImageDrawable(d);
        bubble.setPadding(10, 10, 10, 10);
        int s = 140;
        lp = new WindowManager.LayoutParams(s, s,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = 100; lp.y = 100;
        wm.addView(root, lp);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setVisibility(View.GONE);
        box.setBackgroundColor(0xFF21252B);
        box.setPadding(20, 20, 20, 20);
        root.addView(box, new FrameLayout.LayoutParams(-1, -1));
        TextView title = new TextView(this);
        title.setText("Virtual Sound");
        title.setTextColor(-1);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));
        ImageView min = new ImageView(this);
        min.setImageDrawable(getDrawable(R.drawable.ic_minimize));
        min.setPadding(0, 10, 0, 10);
        min.setOnClickListener(v -> collapse());
        box.addView(min, new LinearLayout.LayoutParams(-1, -2));
        ImageView stop = new ImageView(this);
        stop.setImageResource(android.R.drawable.ic_media_pause);
        stop.setPadding(0, 10, 0, 10);
        stop.setOnClickListener(v -> Player.stop(this));
        box.addView(stop, new LinearLayout.LayoutParams(-1, -2));
        bubble.setOnTouchListener(new Drag(() -> expand()));
        root.addView(bubble, lp);
    }

    void expand() {
        bubble.setVisibility(View.GONE);
        box.setVisibility(View.VISIBLE);
        panel.refresh();
    }

    void collapse() {
        box.setVisibility(View.GONE);
        bubble.setVisibility(View.VISIBLE);
    }

    public void onTaskRemoved(Intent rootIntent) {
        Player.stop(this);
        stopForeground(true);
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    public void onDestroy() {
        if (root != null) wm.removeView(root);
        super.onDestroy();
    }
}
