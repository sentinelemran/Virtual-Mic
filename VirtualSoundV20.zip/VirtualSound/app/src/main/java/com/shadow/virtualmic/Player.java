package com.shadow.virtualmic;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;

public class Player {
    public static float gain = 1f;
    public static boolean playing;
    public static Store.Item last;
    public static boolean preview;
    static AudioTrack at;
    static Handler H = new Handler(Looper.getMainLooper());
    static List<Runnable> LS = new ArrayList<>();
    static Process currentProcess; // শিজুকু প্রসেস ট্র্যাক করার জন্য

    static final Runnable END = new Runnable() {
        public void run() { playing = false; fire(); }
    };

    static void add(Runnable r) { LS.add(r); }
    static void remove(Runnable r) { LS.remove(r); }
    static void fire() { for (Runnable r : new ArrayList<>(LS)) r.run(); }

    public static synchronized void stopAudio() {
        if (currentProcess != null) {
            currentProcess.destroy();
            currentProcess = null;
        }
        localStop();
    }

    public static void play(Context c, Store.Item it) {
        stopAudio(); // নতুন অডিওর আগে আগেরটা পুরোপুরি বন্ধ হবে
        byte[] d = Store.read(it.pcm);
        if (d == null || d.length < 2) return;
        send(c, d);
        localPlay(d);
        if (Mic.running()) {
            short[] s16 = new short[d.length / 2];
            ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s16);
            Mic.play(c, s16, gain);
        }
        last = it;
        playing = true;
        H.removeCallbacks(END);
        H.postDelayed(END, d.length / 32 + 300);
        fire();
    }

    public static void stop(Context c) {
        stopAudio();
        if (Mic.running()) Mic.stopSound(c);
        playing = false;
        H.removeCallbacks(END);
        fire();
    }

    static void localStop() {
        if (at != null) {
            try { at.stop(); } catch (Exception e) {}
            try { at.release(); } catch (Exception e) {}
            at = null;
        }
    }

    static void localPlay(byte[] d) {
        localStop();
        try {
            int n = d.length / 2;
            short[] s = new short[n];
            ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s);
            for (int i = 0; i < n; i++) {
                int v = (int) (s[i] * gain);
                s[i] = (short) Math.max(-32768, Math.min(32767, v));
            }
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, 16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, n * 2, AudioTrack.MODE_STATIC);
            t.write(s, 0, n);
            t.play();
            at = t;
        } catch (Exception e) {}
    }

    static void send(Context c, byte[] d) {
        Intent i = new Intent("com.shadow.virtualmic.MIC_Sy");
        i.putExtra("pcm", d);
        c.sendBroadcast(i);
    }
}
