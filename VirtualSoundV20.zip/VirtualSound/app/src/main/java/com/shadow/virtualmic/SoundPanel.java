package com.shadow.virtualmic;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Shared UI: boost, play/stop, sound grid, folders. Used in the app and in the floating window. */
public class SoundPanel extends LinearLayout {
    public interface Host { void addSound(); }

    static final int BG = 0xFF07070D, CARD = 0xFF12121E, BD = 0xFF25254A, C1 = 0xFF00F0FF,
            C2 = 0xFFFF2BD6, RED = 0xFFFF3B5C, MUT = 0xFF7D80A8, TXT = 0xFFEEF0FF;

    final Host host;
    final boolean editable;
    final boolean compact;
    File folder;
    LinearLayout grid, folderBar, selectBar;
    TextView boostVal, folderName, selectCount;
    Button pb, renameBtn;
    final Runnable listener = new Runnable() { public void run() { updatePb(); } };
    final java.util.Set<String> selectedKeys = new java.util.LinkedHashSet<>();

    static String key(Store.Item it) { return it.folder ? it.dir.getAbsolutePath() : it.pcm.getAbsolutePath(); }
    public int selectionCount() { return selectedKeys.size(); }
    public void clearSelection() { selectedKeys.clear(); refresh(); }

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    static GradientDrawable rect(Context c, int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(c, 1.5f), stroke);
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static class Tile extends LinearLayout {
        Tile(Context c) { super(c); }
        @Override protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(w), MeasureSpec.EXACTLY));
        }
    }

    public SoundPanel(final Context c, Host h, boolean ed) { this(c, h, ed, false); }

    public SoundPanel(final Context c, Host h, boolean ed, boolean cpt) {
        super(c);
        host = h;
        editable = ed;
        compact = cpt;
        setOrientation(VERTICAL);

        float padH = compact ? 8 : 14, padV1 = compact ? 6 : 10, padV2 = compact ? 3 : 6;
        float labelSp = compact ? 10 : 13, valSp = compact ? 12 : 15;
        int cardBottom = compact ? 6 : 10, pbHeight = compact ? 36 : 48, pbBottom = compact ? 6 : 10;
        float pbTextSp = compact ? 12 : 15;

        // boost card
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(VERTICAL);
        card.setPadding(dp(c, padH), dp(c, padV1), dp(c, padH), dp(c, padV2));
        card.setBackground(rect(c, CARD, BD, 16));
        LinearLayout row = new LinearLayout(c);
        TextView l = tv(c, "Volume boost", labelSp, MUT);
        row.addView(l, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
        boostVal = tv(c, String.format("%.1fx", Player.gain), valSp, C1);
        boostVal.setTypeface(null, Typeface.BOLD);
        row.addView(boostVal);
        card.addView(row);
        SeekBar sb = new SeekBar(c);
        sb.setMax(40);
        sb.setProgress(Math.round(Player.gain * 10));
        sb.setProgressTintList(ColorStateList.valueOf(C1));
        sb.setThumbTintList(ColorStateList.valueOf(C1));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                Player.gain = Math.max(0.1f, p / 10f);
                boostVal.setText(String.format("%.1fx", Player.gain));
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        if (compact) sb.setPadding(0, 0, 0, 0);
        card.addView(sb);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        cl.bottomMargin = dp(c, cardBottom);
        addView(card, cl);

        // play / stop
        pb = new Button(c);
        pb.setAllCaps(false);
        pb.setTextSize(pbTextSp);
        pb.setTypeface(null, Typeface.BOLD);
        pb.setStateListAnimator(null);
        if (compact) pb.setPadding(0, 0, 0, 0);
        pb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (Player.playing) Player.stop(c);
                else if (Player.last != null && Player.last.pcm.exists()) Player.play(c, Player.last);
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(c, pbHeight));
        pl.bottomMargin = dp(c, pbBottom);
        addView(pb, pl);

        // folder bar
        folderBar = new LinearLayout(c);
        folderBar.setGravity(Gravity.CENTER_VERTICAL);
        folderBar.setVisibility(GONE);
        Button back = new Button(c);
        back.setAllCaps(false);
        back.setText("\u2190 Back");
        back.setTextColor(C1);
        back.setTextSize(compact ? 11 : 14);
        if (compact) back.setPadding(dp(c, 8), 0, dp(c, 8), 0);
        back.setBackground(rect(c, 0, C1, 12));
        back.setStateListAnimator(null);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { folder = null; refresh(); }
        });
        folderBar.addView(back, new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(c, compact ? 30 : 40)));
        folderName = tv(c, "", compact ? 12 : 16, C2);
        folderName.setTypeface(null, Typeface.BOLD);
        folderName.setPadding(dp(c, compact ? 8 : 12), 0, 0, 0);
        folderBar.addView(folderName);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        fl.bottomMargin = dp(c, compact ? 5 : 8);
        addView(folderBar, fl);

        // selection bar - only appears while long-pressed items are selected
        if (editable) {
            selectBar = new LinearLayout(c);
            selectBar.setGravity(Gravity.CENTER_VERTICAL);
            selectBar.setVisibility(GONE);
            selectBar.setBackground(rect(c, CARD, C2, 14));
            int sp = dp(c, 8);
            selectBar.setPadding(sp, sp, sp, sp);
            selectCount = tv(c, "", 13, TXT);
            selectCount.setTypeface(null, Typeface.BOLD);
            selectBar.addView(selectCount, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
            renameBtn = new Button(c);
            renameBtn.setAllCaps(false);
            renameBtn.setText("Rename");
            renameBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { renameSelected(); } });
            LinearLayout.LayoutParams rbp = new LinearLayout.LayoutParams(-2, -2);
            rbp.leftMargin = dp(c, 6);
            selectBar.addView(renameBtn, rbp);
            Button delBtn = new Button(c);
            delBtn.setAllCaps(false);
            delBtn.setText("Delete");
            delBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { deleteSelected(); } });
            LinearLayout.LayoutParams dbp = new LinearLayout.LayoutParams(-2, -2);
            dbp.leftMargin = dp(c, 6);
            selectBar.addView(delBtn, dbp);
            Button cancelBtn = new Button(c);
            cancelBtn.setAllCaps(false);
            cancelBtn.setText("\u2715");
            cancelBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { clearSelection(); } });
            LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(-2, -2);
            cbp.leftMargin = dp(c, 6);
            selectBar.addView(cancelBtn, cbp);
            LinearLayout.LayoutParams sbl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            sbl.bottomMargin = dp(c, 8);
            addView(selectBar, sbl);
        }

        // grid
        ScrollView sv = new ScrollView(c);
        grid = new LinearLayout(c);
        grid.setOrientation(VERTICAL);
        if (ed && !compact) grid.setPadding(0, 0, 0, dp(c, 80));
        sv.addView(grid, new ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1));

        updatePb();
        refresh();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Player.add(listener);
        updatePb();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Player.remove(listener);
    }

    void updatePb() {
        Context c = getContext();
        boolean p = Player.playing;
        pb.setText(p ? "\u25A0  STOP" : "\u25B6  PLAY");
        int col = p ? RED : C1;
        pb.setTextColor(col);
        pb.setBackground(rect(c, p ? 0x22FF3B5C : 0x1400F0FF, col, 14));
    }

    public void refresh() {
        Context c = getContext();
        if (selectBar != null) {
            boolean any = !selectedKeys.isEmpty();
            selectBar.setVisibility(any ? VISIBLE : GONE);
            if (any) {
                selectCount.setText(selectedKeys.size() + " selected");
                renameBtn.setVisibility(selectedKeys.size() == 1 && !isSingleSelectedAFolder() ? VISIBLE : GONE);
            }
        }
        grid.removeAllViews();
        List<View> tiles = new ArrayList<>();
        if (folder == null) {
            for (Store.Item it : Store.sounds(c, Store.soundsDir(c))) tiles.add(tile(it));
            for (Store.Item it : Store.folderItems(c)) tiles.add(tile(it));
            if (editable) tiles.add(addTile());
            folderBar.setVisibility(GONE);
        } else {
            for (Store.Item it : Store.sounds(c, folder)) tiles.add(tile(it));
            folderName.setText("\uD83D\uDCC1 " + folder.getName());
            folderBar.setVisibility(VISIBLE);
        }
        int m = dp(c, compact ? 2 : 4);
        LinearLayout row = null;
        for (int i = 0; i < tiles.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(c);
                grid.addView(row, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(m, m, m, m);
            row.addView(tiles.get(i), lp);
        }
        if (row != null) {
            for (int k = tiles.size() % 3; k > 0 && k < 3; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1);
                lp.setMargins(m, m, m, m);
                row.addView(new View(c), lp);
            }
        }
    }

    static String emoji(Store.Item it) {
        if (it.folder) return "\uD83D\uDCC1";
        switch (it.name) {
            case "Air Horn": return "\uD83D\uDCE2";
            case "Bruh": return "\uD83D\uDE10";
            case "Sad Horn": return "\uD83D\uDE22";
            case "Explosion": return "\uD83D\uDCA5";
            case "Laugh": return "\uD83D\uDE02";
            case "Drum": return "\uD83E\uDD41";
        }
        return "\uD83C\uDFB5";
    }

    Tile baseTile(String label, View icon) {
        final Context c = getContext();
        Tile t = new Tile(c);
        t.setOrientation(VERTICAL);
        t.setGravity(Gravity.CENTER);
        int p = dp(c, compact ? 3 : 6);
        t.setPadding(p, p, p, p);
        t.setBackground(rect(c, CARD, BD, compact ? 10 : 16));
        t.addView(icon);
        TextView n = tv(c, label, compact ? 9 : 12, TXT);
        n.setGravity(Gravity.CENTER);
        n.setMaxLines(compact ? 1 : 2);
        n.setEllipsize(TextUtils.TruncateAt.END);
        n.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        nl.topMargin = dp(c, compact ? 2 : 4);
        t.addView(n, nl);
        return t;
    }

    View tile(final Store.Item it) {
        final Context c = getContext();
        View icon;
        if (it.icon != null) {
            ImageView iv = new ImageView(c);
            Bitmap b = BitmapFactory.decodeFile(it.icon.getPath());
            iv.setImageBitmap(b);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            int isz = compact ? 22 : 38;
            iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, isz), dp(c, isz)));
            icon = iv;
        } else {
            TextView e = tv(c, emoji(it), compact ? 16 : 26, TXT);
            e.setGravity(Gravity.CENTER);
            icon = e;
        }
        final Tile t = baseTile(it.name, icon);
        final boolean isSel = selectedKeys.contains(key(it));
        if (isSel) {
            t.setBackground(rect(c, 0x3300F0FF, C1, compact ? 10 : 16));
        }
        final Tile t2 = t;
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (editable && !selectedKeys.isEmpty()) {
                    toggleSelect(it);
                    return;
                }
                flash(t2);
                if (it.folder) { folder = it.dir; refresh(); }
                else Player.play(c, it);
            }
        });
        if (editable) {
            t.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    toggleSelect(it);
                    return true;
                }
            });
        }
        return t;
    }

    void toggleSelect(Store.Item it) {
        String k = key(it);
        if (!selectedKeys.remove(k)) selectedKeys.add(k);
        refresh();
    }

    List<Store.Item> currentItems() {
        Context c = getContext();
        List<Store.Item> all = new ArrayList<>();
        if (folder == null) {
            all.addAll(Store.sounds(c, Store.soundsDir(c)));
            all.addAll(Store.folderItems(c));
        } else {
            all.addAll(Store.sounds(c, folder));
        }
        return all;
    }

    List<Store.Item> resolveSelected() {
        List<Store.Item> out = new ArrayList<>();
        for (Store.Item it : currentItems()) if (selectedKeys.contains(key(it))) out.add(it);
        return out;
    }

    boolean isSingleSelectedAFolder() {
        if (selectedKeys.size() != 1) return false;
        return new File(selectedKeys.iterator().next()).isDirectory();
    }

    void deleteSelected() {
        final Context c = getContext();
        final List<Store.Item> items = resolveSelected();
        if (items.isEmpty()) { clearSelection(); return; }
        String msg = items.size() == 1 ? ("Delete \"" + items.get(0).name + "\"?") : ("Delete " + items.size() + " items?");
        new AlertDialog.Builder(c).setTitle(msg)
                .setPositiveButton("Delete", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        for (Store.Item it : items) Store.delete(it);
                        selectedKeys.clear();
                        refresh();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    void renameSelected() {
        final Context c = getContext();
        List<Store.Item> items = resolveSelected();
        if (items.size() != 1) return;
        final Store.Item it = items.get(0);
        final EditText input = new EditText(c);
        input.setText(it.name);
        input.setSingleLine();
        input.setSelection(input.getText().length());
        new AlertDialog.Builder(c).setTitle("Rename").setView(input)
                .setPositiveButton("Save", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        String nm = input.getText().toString().trim();
                        if (!nm.isEmpty()) Store.rename(it, nm);
                        selectedKeys.clear();
                        refresh();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    View addTile() {
        final Context c = getContext();
        TextView plus = tv(c, "+", compact ? 18 : 30, C1);
        plus.setGravity(Gravity.CENTER);
        Tile t = baseTile("Add sound", plus);
        GradientDrawable g = rect(c, 0, 0xFF3A3A70, 16);
        g.setStroke(dp(c, 1.5f), 0xFF3A3A70, dp(c, 6), dp(c, 4));
        t.setBackground(g);
        if (!compact) {
            t.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { if (host != null) host.addSound(); }
            });
        }
        return t;
    }

    void flash(final View t) {
        final Context c = getContext();
        t.setBackground(rect(c, 0x3300F0FF, C1, 16));
        t.postDelayed(new Runnable() {
            public void run() { t.setBackground(rect(c, CARD, BD, 16)); }
        }, 300);
    }
}
