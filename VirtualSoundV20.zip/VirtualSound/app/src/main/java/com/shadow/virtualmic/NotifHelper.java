package com.shadow.virtualmic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** A small always-on notification mirroring the in-app connection status. */
public class NotifHelper {
    static final String CH = "vs_status";
    static final int ID = 501;

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(CH) == null) {
            NotificationChannel ch = new NotificationChannel(CH, "Virtual Sound status", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    /** running=true shows "Running", false shows "Not running". detail is the short status line under it. */
    static void update(Context c, boolean running, String detail) {
        try {
            ensureChannel(c);
            Intent open = new Intent(c, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            PendingIntent pi = PendingIntent.getActivity(c, 0, open, flags);

            Notification.Builder b = (Build.VERSION.SDK_INT >= 26)
                    ? new Notification.Builder(c, CH)
                    : new Notification.Builder(c);
            b.setContentTitle("Virtual Sound \u2014 " + (running ? "Running" : "Not running"))
                    .setContentText(detail)
                    .setSmallIcon(running ? android.R.drawable.presence_online : android.R.drawable.presence_offline)
                    .setOngoing(running)
                    .setContentIntent(pi)
                    .setOnlyAlertOnce(true);

            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(ID, b.build());
        } catch (Throwable e) { /* notifications are a convenience, never crash over them */ }
    }

    static void clear(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel(ID);
        } catch (Throwable e) { }
    }
}
