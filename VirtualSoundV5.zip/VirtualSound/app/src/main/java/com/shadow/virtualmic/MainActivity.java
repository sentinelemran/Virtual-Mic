package com.shadow.virtualmic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity implements SoundPanel.Host {
    SoundPanel panel;
    TextView micStatus;
    boolean suppress;
    static final int SHIZUKU_PERM_CODE = 7001;
    final Shizuku.OnRequestPermissionResultListener permListener = (code, result) -> {
        if (code != SHIZUKU_PERM_CODE) return;
        if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) startShizuku();
        else toast("Shizuku permission denied");
    };
    Uri pAudio, pIcon;
    TextView aLbl, iLbl;

    int dp(float v) { return SoundPanel.dp(this, v); }

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(SoundPanel.BG);
        getWindow().setNavigationBarColor(SoundPanel.BG);
        Store.ensureBuiltins(this);

        FrameLayout frame = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SoundPanel.BG);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_XY);
        GradientDrawable lg = new GradientDrawable();
        lg.setShape(GradientDrawable.OVAL);
        lg.setColor(0xFF0B0B18);
        lg.setStroke(dp(1.5f), SoundPanel.C1);
        logo.setBackground(lg);
        logo.setClipToOutline(true);
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lgp.rightMargin = dp(10);
        head.addView(logo, lgp);

        TextView title = new TextView(this);
        SpannableString ss = new SpannableString("VIRTUAL SOUND");
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C1), 0, 8, 0);
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C2), 8, 13, 0);
        title.setText(ss);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        title.setShadowLayer(12, 0, 0, SoundPanel.C1);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(iconBtn(R.drawable.ic_add_folder, "Add folder", v -> importFolder()));
        head.addView(iconBtn(R.drawable.ic_minimize, "Minimize", v -> minimize()));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.bottomMargin = dp(12);
        root.addView(head, hl);

        root.addView(micCard(), new LinearLayout.LayoutParams(-1, -2));

        panel = new SoundPanel(this, this, true);
        root.addView(panel, new LinearLayout.LayoutParams(-1, 0, 1));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        TextView fab = SoundPanel.tv(this, "?", 24, SoundPanel.BG);
        fab.setTypeface(null, Typeface.BOLD);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable fg = new GradientDrawable();
        fg.setShape(GradientDrawable.OVAL);
        fg.setColor(SoundPanel.C1);
        fab.setBackground(fg);
        fab.setElevation(dp(6));
        fab.setOnClickListener(v -> showHelp());
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(54), dp(54));
        fp.gravity = Gravity.BOTTOM | Gravity.END;
        fp.setMargins(0, 0, dp(20), dp(24));
        frame.addView(fab, fp);
        setContentView(frame);

        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable e) { }
        askOverlay();
    }

    View iconBtn(int res, String desc, View.OnClickListener l) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        int p = dp(10);
        v.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0);
        g.setStroke(dp(1.5f), SoundPanel.C1);
        v.setBackground(g);
        v.setContentDescription(desc);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lp.leftMargin = dp(8);
        v.setLayoutParams(lp);
        return v;
    }

    boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    void launch(Intent i, int code) {
        suppress = true;
        startActivityForResult(i, code);
    }

    void askOverlay() {
        if (canOverlay()) return;
        new AlertDialog.Builder(this).setTitle("Permission needed")
                .setMessage("Allow \"Display over other apps\" so Virtual Sound can float over your game when minimized.")
                .setPositiveButton("Allow", (d, w) -> launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())), 9))
                .setNegativeButton("Later", null).show();
    }

    void startOverlay() {
        if (canOverlay()) startService(new Intent(this, OverlayService.class));
    }

    void minimize() {
        if (!canOverlay()) { askOverlay(); return; }
        startOverlay();
        moveTaskToBack(true);
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!suppress) startOverlay();
    }

    @Override protected void onResume() {
        super.onResume();
        suppress = false;
        stopService(new Intent(this, OverlayService.class));
        if (panel != null) panel.refresh();
    }

    void toast(final String s) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show());
    }


    View micCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackground(SoundPanel.rect(this, 0xFF12121E, 0xFF25254A, 16));
        micStatus = SoundPanel.tv(this, "Injection: OFF (sounds only reach your own speaker if enabled below)", 12, SoundPanel.MUT);
        card.addView(micStatus);
        LinearLayout row = new LinearLayout(this);
        Button rb = new Button(this); rb.setAllCaps(false); rb.setText("Use Root");
        rb.setOnClickListener(v -> startRoot());
        Button sb = new Button(this); sb.setAllCaps(false); sb.setText("Use Shizuku");
        sb.setOnClickListener(v -> startShizukuFlow());
        Button xb = new Button(this); xb.setAllCaps(false); xb.setText("Stop");
        xb.setOnClickListener(v -> { Mic.stop(this); setMicStatus(false, "Injection: OFF"); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.rightMargin = dp(6);
        row.addView(rb, lp);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1);
        lp2.rightMargin = dp(6);
        row.addView(sb, lp2);
        row.addView(xb, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(8);
        card.addView(row, rl);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
        cl.bottomMargin = dp(10);
        card.setLayoutParams(cl);
        return card;
    }

    void setMicStatus(boolean ok, String msg) {
        if (micStatus == null) return;
        micStatus.setText(msg);
        micStatus.setTextColor(ok ? SoundPanel.C1 : SoundPanel.MUT);
    }

    void startRoot() {
        setMicStatus(false, "Starting root injector...");
        Mic.startRoot(this, (ok, msg) -> setMicStatus(ok, (ok ? "ROOT " : "") + msg));
    }

    void startShizukuFlow() {
        if (!Mic.shizukuAvailable()) { toast("Shizuku is not running. Open the Shizuku app first."); return; }
        if (!Mic.shizukuGranted()) { Mic.requestShizukuPermission(SHIZUKU_PERM_CODE); return; }
        startShizuku();
    }

    void startShizuku() {
        setMicStatus(false, "Starting Shizuku injector...");
        Mic.startShizuku(this, (ok, msg) -> setMicStatus(ok, (ok ? "SHIZUKU " : "") + msg));
    }

    void importFolder() { launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); }

    Intent pick(String type, String[] mimes) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType(type);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (mimes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
        return i;
    }

    public void addSound() {
        pAudio = null;
        pIcon = null;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(20), dp(10), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine();
        v.addView(name);
        Button ab = new Button(this);
        ab.setAllCaps(false);
        ab.setText("Audio:  Browse");
        ab.setOnClickListener(x -> launch(pick("*/*", new String[]{"audio/*", "video/*"}), 1));
        v.addView(ab);
        aLbl = new TextView(this);
        aLbl.setText("No file selected");
        v.addView(aLbl);
        Button ib = new Button(this);
        ib.setAllCaps(false);
        ib.setText("Icon / Image:  Browse");
        ib.setOnClickListener(x -> launch(pick("image/*", null), 3));
        v.addView(ib);
        iLbl = new TextView(this);
        iLbl.setText("Optional");
        v.addView(iLbl);

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add sound").setView(v)
                .setPositiveButton("Save", null).setNegativeButton("Cancel", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            if (pAudio == null) { toast("Choose an audio file first"); return; }
            save(name.getText().toString().trim());
            dlg.dismiss();
        });
    }

    void save(final String nm) {
        final Uri a = pAudio, ic = pIcon;
        toast("Saving...");
        new Thread(() -> {
            try {
                String base = Store.clean(nm.isEmpty() ? Store.displayName(this, a) : nm, nm.isEmpty());
                short[] s = Store.decode(this, a);
                File dir = Store.soundsDir(this);
                Store.savePcm(dir, base, s, System.currentTimeMillis());
                if (ic != null) Store.saveIcon(this, ic, new File(dir, base + ".png"));
                runOnUiThread(() -> panel.refresh());
                toast("Added");
            } catch (Exception e) { toast("Failed: " + e.getMessage()); }
        }).start();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rs != RESULT_OK || d == null || d.getData() == null) return;
        final Uri u = d.getData();
        if (rq == 1) {
            pAudio = u;
            if (aLbl != null) aLbl.setText(Store.displayName(this, u));
        } else if (rq == 3) {
            pIcon = u;
            if (iLbl != null) iLbl.setText(Store.displayName(this, u));
        } else if (rq == 2) {
            toast("Importing folder...");
            new Thread(() -> {
                final int n = Store.importTree(this, u);
                runOnUiThread(() -> panel.refresh());
                toast(n > 0 ? "Imported " + n + " sounds" : "No audio files found in that folder");
            }).start();
        }
    }

    // ---------------- Help ----------------

    TextView addT(LinearLayout b, String s, float sp, int col, boolean bold, int top) {
        TextView t = SoundPanel.tv(this, s, sp, col);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        b.addView(t, p);
        return t;
    }

    Button addB(LinearLayout b, String s, View.OnClickListener l) {
        Button x = new Button(this);
        x.setAllCaps(false);
        x.setText(s);
        x.setOnClickListener(l);
        b.addView(x, new LinearLayout.LayoutParams(-1, -2));
        return x;
    }

    void copyLog() {
        String log = Mic.lastLog(this);
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Virtual Sound log", log));
        toast("Log copied, paste it to share");
    }

    void showHelp() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(14), dp(18), dp(10));
        sv.addView(box);
        helpAsk(box);
        new AlertDialog.Builder(this).setView(sv).setPositiveButton("Close", null).show();
    }

    void helpAsk(final LinearLayout b) {
        b.removeAllViews();
        addT(b, "Help & Setup", 20, SoundPanel.C1, true, 0);
        addT(b, "This app is for ROOTED phones (or phones with Shizuku). It puts your sounds into the game's microphone using Android's own audio system, no LSPosed/Xposed needed.", 14, SoundPanel.TXT, false, 10);

        addT(b, "Option A: Root", 15, SoundPanel.C2, true, 16);
        addT(b, "1. Make sure your phone is rooted (Magisk, Kitsune Mask, KernelSU, APatch...).\n2. Open Virtual Sound, tap \"Use Root\" near the top, and allow the root (su) prompt.\n3. Status should turn to \"Injection is ON\".", 14, SoundPanel.TXT, false, 6);

        addT(b, "Option B: Shizuku (works without root too)", 15, SoundPanel.C2, true, 16);
        addT(b, "1. Install the Shizuku app (Play Store or github.com/RikkaApps/Shizuku/releases).\n2. Start it: on Android 11+ use Wireless debugging (Developer options > Wireless debugging > pair, then in Shizuku tap \"Start via Wireless debugging\"); or start it from a rooted shell if you have root.\n3. Open Virtual Sound, tap \"Use Shizuku\", allow the permission popup.\n4. Status should turn to \"Injection is ON\". You must restart Shizuku after every phone reboot.", 14, SoundPanel.TXT, false, 6);

        addT(b, "Then, for any mode", 15, SoundPanel.C2, true, 16);
        addT(b, "1. Allow \"Display over other apps\" when asked.\n2. Open the game, turn on voice chat and your mic.\n3. Minimize Virtual Sound (top-right icon, or press Home). Tap the floating bubble, then tap a sound.\n4. You will not hear the sound yourself unless \"Hear sounds myself (test)\" is on; teammates hear it through your mic.", 14, SoundPanel.TXT, false, 6);

        addT(b, "Not working?", 16, SoundPanel.C2, true, 18);
        addT(b, "If the status button does not turn on, or no sound reaches the game, copy the log below and send it so it can be fixed.", 14, SoundPanel.TXT, false, 6);
        addB(b, "Copy diagnostic log", v -> copyLog());

        addT(b, "Warning: root/Shizuku audio injection can get a game account banned by the game's rules. Try with a spare account first.", 13, SoundPanel.RED, false, 14);
    }
}
