package de.robv.android.xposed;
import java.util.Set;
public class XposedBridge {
    public static void log(String s) { }
    public static void log(Throwable t) { }
    public static Set<XC_MethodHook.Unhook> hookAllMethods(Class<?> c, String name, XC_MethodHook cb) { return null; }
}
