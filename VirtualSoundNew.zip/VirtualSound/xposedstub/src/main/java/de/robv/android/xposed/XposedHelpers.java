package de.robv.android.xposed;
public class XposedHelpers {
    public static XC_MethodHook.Unhook findAndHookMethod(Class<?> c, String name, Object... params) { return null; }
}
