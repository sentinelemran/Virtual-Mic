package com.shadow.virtualmic;

import java.util.Random;

/** Tiny synth that renders the built-in sounds as 16kHz mono PCM. */
public class Synth {
    static final int R = 16000;
    final float[] b;
    static final Random RND = new Random(7);

    Synth(double sec) { b = new float[(int) (sec * R) + 1]; }

    // type: 0 sine, 1 saw, 2 square
    Synth osc(int type, double f1, double f2, double dur, double vol, double t0) {
        int s0 = (int) (t0 * R), n = (int) (dur * R);
        double ph = 0;
        for (int i = 0; i < n && s0 + i < b.length; i++) {
            double x = (double) i / n;
            double f = f1 * Math.pow(f2 / f1, x);
            ph += 2 * Math.PI * f / R;
            double p = (ph / (2 * Math.PI)) % 1.0;
            double w = type == 0 ? Math.sin(ph) : type == 1 ? 2 * p - 1 : (p < .5 ? 1 : -1);
            double env = vol * Math.pow(0.001 / vol, x);
            b[s0 + i] += (float) (w * env);
        }
        return this;
    }

    Synth noise(double dur, double vol) {
        int n = (int) (dur * R);
        for (int i = 0; i < n && i < b.length; i++) {
            double x = (double) i / n;
            double env = vol * Math.pow(0.001 / vol, x);
            b[i] += (float) ((RND.nextDouble() * 2 - 1) * env);
        }
        return this;
    }

    short[] out() {
        float peak = 0;
        for (float v : b) peak = Math.max(peak, Math.abs(v));
        float k = peak > 0 ? 0.9f / peak : 1f;
        short[] s = new short[b.length];
        for (int i = 0; i < b.length; i++) s[i] = (short) (b[i] * k * 32767);
        return s;
    }

    static short[] airHorn() { return new Synth(1.2).osc(1, 440, 430, 1.2, .5, 0).osc(1, 554, 540, 1.2, .5, 0).osc(2, 220, 215, 1.2, .3, 0).out(); }
    static short[] bruh() { return new Synth(.6).osc(1, 140, 60, .6, .9, 0).osc(2, 70, 40, .6, .5, 0).out(); }
    static short[] sadHorn() {
        Synth s = new Synth(2.05);
        double[] f = {392, 370, 349, 330};
        for (int k = 0; k < 4; k++) s.osc(1, f[k], f[k] * .97, .55, .5, k * .5);
        return s.out();
    }
    static short[] explosion() { return new Synth(1.2).noise(1.2, 1).osc(0, 90, 25, 1.2, 1, 0).out(); }
    static short[] laugh() {
        Synth s = new Synth(1.1);
        for (int k = 0; k < 6; k++) s.osc(1, 380 + (k % 2) * 60, 300, .12, .5, k * .16);
        return s.out();
    }
    static short[] drum() { return new Synth(.35).osc(0, 160, 40, .35, 1, 0).noise(.15, .5).out(); }
}
