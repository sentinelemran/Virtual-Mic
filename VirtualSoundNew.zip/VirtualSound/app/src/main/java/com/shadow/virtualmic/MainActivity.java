package com.shadow.virtualmic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements SoundPanel.Host {
    SoundPanel panel;
    boolean suppress;
    Uri pAudio, pIcon;
    TextView aLbl, iLbl;

    int dp(float v) { return SoundPanel.dp(this, v); }

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(SoundPanel.BG);
        getWindow().setNavigationBarColor(SoundPanel.BG);
        Store.ensureBuiltins(this);

        FrameLayout frame = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SoundPanel.BG);
        root.setPadding(dp(16), dp(16), dp(16), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_XY);
        GradientDrawable lg = new GradientDrawable();
        lg.setShape(GradientDrawable.OVAL);
        lg.setColor(0xFF0B0B18);
        lg.setStroke(dp(1.5f), SoundPanel.C1);
        logo.setBackground(lg);
        logo.setClipToOutline(true);
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lgp.rightMargin = dp(10);
        head.addView(logo, lgp);

        TextView title = new TextView(this);
        SpannableString ss = new SpannableString("VIRTUAL SOUND");
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C1), 0, 8, 0);
        ss.setSpan(new ForegroundColorSpan(SoundPanel.C2), 8, 13, 0);
        title.setText(ss);
        title.setTextSize(19);
        title.setTypeface(null, Typeface.BOLD);
        title.setLetterSpacing(0.08f);
        title.setShadowLayer(12, 0, 0, SoundPanel.C1);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(iconBtn(R.drawable.ic_add_folder, "Add folder", v -> importFolder()));
        head.addView(iconBtn(R.drawable.ic_minimize, "Minimize", v -> minimize()));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2);
        hl.bottomMargin = dp(12);
        root.addView(head, hl);

        panel = new SoundPanel(this, this, true);
        root.addView(panel, new LinearLayout.LayoutParams(-1, 0, 1));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));

        TextView fab = SoundPanel.tv(this, "?", 24, SoundPanel.BG);
        fab.setTypeface(null, Typeface.BOLD);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable fg = new GradientDrawable();
        fg.setShape(GradientDrawable.OVAL);
        fg.setColor(SoundPanel.C1);
        fab.setBackground(fg);
        fab.setElevation(dp(6));
        fab.setOnClickListener(v -> showHelp());
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(54), dp(54));
        fp.gravity = Gravity.BOTTOM | Gravity.END;
        fp.setMargins(0, 0, dp(20), dp(24));
        frame.addView(fab, fp);
        setContentView(frame);

        askOverlay();
    }

    View iconBtn(int res, String desc, View.OnClickListener l) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        int p = dp(10);
        v.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0);
        g.setStroke(dp(1.5f), SoundPanel.C1);
        v.setBackground(g);
        v.setContentDescription(desc);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        lp.leftMargin = dp(8);
        v.setLayoutParams(lp);
        return v;
    }

    boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    void launch(Intent i, int code) {
        suppress = true;
        startActivityForResult(i, code);
    }

    void askOverlay() {
        if (canOverlay()) return;
        new AlertDialog.Builder(this).setTitle("Permission needed")
                .setMessage("Allow \"Display over other apps\" so Virtual Sound can float over your game when minimized.")
                .setPositiveButton("Allow", (d, w) -> launch(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())), 9))
                .setNegativeButton("Later", null).show();
    }

    void startOverlay() {
        if (canOverlay()) startService(new Intent(this, OverlayService.class));
    }

    void minimize() {
        if (!canOverlay()) { askOverlay(); return; }
        startOverlay();
        moveTaskToBack(true);
    }

    @Override protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!suppress) startOverlay();
    }

    @Override protected void onResume() {
        super.onResume();
        suppress = false;
        stopService(new Intent(this, OverlayService.class));
        if (panel != null) panel.refresh();
    }

    void toast(final String s) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show());
    }

    void importFolder() { launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2); }

    Intent pick(String type, String[] mimes) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType(type);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (mimes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
        return i;
    }

    public void addSound() {
        pAudio = null;
        pIcon = null;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(dp(20), dp(10), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Name");
        name.setSingleLine();
        v.addView(name);
        Button ab = new Button(this);
        ab.setAllCaps(false);
        ab.setText("Audio:  Browse");
        ab.setOnClickListener(x -> launch(pick("*/*", new String[]{"audio/*", "video/*"}), 1));
        v.addView(ab);
        aLbl = new TextView(this);
        aLbl.setText("No file selected");
        v.addView(aLbl);
        Button ib = new Button(this);
        ib.setAllCaps(false);
        ib.setText("Icon / Image:  Browse");
        ib.setOnClickListener(x -> launch(pick("image/*", null), 3));
        v.addView(ib);
        iLbl = new TextView(this);
        iLbl.setText("Optional");
        v.addView(iLbl);

        final AlertDialog dlg = new AlertDialog.Builder(this).setTitle("Add sound").setView(v)
                .setPositiveButton("Save", null).setNegativeButton("Cancel", null).create();
        dlg.show();
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            if (pAudio == null) { toast("Choose an audio file first"); return; }
            save(name.getText().toString().trim());
            dlg.dismiss();
        });
    }

    void save(final String nm) {
        final Uri a = pAudio, ic = pIcon;
        toast("Saving...");
        new Thread(() -> {
            try {
                String base = Store.clean(nm.isEmpty() ? Store.displayName(this, a) : nm, nm.isEmpty());
                short[] s = Store.decode(this, a);
                File dir = Store.soundsDir(this);
                Store.savePcm(dir, base, s, System.currentTimeMillis());
                if (ic != null) Store.saveIcon(this, ic, new File(dir, base + ".png"));
                runOnUiThread(() -> panel.refresh());
                toast("Added");
            } catch (Exception e) { toast("Failed: " + e.getMessage()); }
        }).start();
    }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rs != RESULT_OK || d == null || d.getData() == null) return;
        final Uri u = d.getData();
        if (rq == 1) {
            pAudio = u;
            if (aLbl != null) aLbl.setText(Store.displayName(this, u));
        } else if (rq == 3) {
            pIcon = u;
            if (iLbl != null) iLbl.setText(Store.displayName(this, u));
        } else if (rq == 2) {
            toast("Importing folder...");
            new Thread(() -> {
                final int n = Store.importTree(this, u);
                runOnUiThread(() -> panel.refresh());
                toast(n > 0 ? "Imported " + n + " sounds" : "No audio files found in that folder");
            }).start();
        }
    }

    // ---------------- Help ----------------

    TextView addT(LinearLayout b, String s, float sp, int col, boolean bold, int top) {
        TextView t = SoundPanel.tv(this, s, sp, col);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setLineSpacing(0, 1.15f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        b.addView(t, p);
        return t;
    }

    Button addB(LinearLayout b, String s, View.OnClickListener l) {
        Button x = new Button(this);
        x.setAllCaps(false);
        x.setText(s);
        x.setOnClickListener(l);
        b.addView(x, new LinearLayout.LayoutParams(-1, -2));
        return x;
    }

    void showHelp() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(14), dp(18), dp(10));
        sv.addView(box);
        helpAsk(box);
        new AlertDialog.Builder(this).setView(sv).setPositiveButton("Close", null).show();
    }

    void helpAsk(final LinearLayout b) {
        b.removeAllViews();
        addT(b, "Help & Setup", 20, SoundPanel.C1, true, 0);
        addT(b, "This app is for ROOTED phones only. It needs LSPosed (an Xposed framework) to put your sounds into the game's microphone.", 14, SoundPanel.TXT, false, 10);
        addT(b, "Which app did you use to root your phone?", 15, SoundPanel.C2, true, 16);
        final String[] names = {"Magisk", "Kitsune Mask (Magisk Delta)", "KernelSU / KernelSU Next", "APatch"};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            addB(b, names[i], v -> helpSteps(b, k));
        }
        addB(b, "My phone is not rooted", v -> {
            b.removeAllViews();
            addT(b, "Not rooted", 20, SoundPanel.C1, true, 0);
            addT(b, "Without root this app cannot send sounds into the game's microphone. You need a rooted phone with LSPosed.", 14, SoundPanel.TXT, false, 10);
            addB(b, "\u2190 Back", x -> helpAsk(b));
        });
    }

    void helpSteps(final LinearLayout b, int mgr) {
        b.removeAllViews();
        String[] names = {"Magisk", "Kitsune Mask", "KernelSU", "APatch"};
        addT(b, "Setup for " + names[mgr], 20, SoundPanel.C1, true, 0);
        addT(b, "Rooted phones only.", 13, SoundPanel.MUT, false, 4);

        List<String> st = new ArrayList<>();
        String zip = "On your phone's browser open github.com/JingMatrix/LSPosed/releases and download the file named LSPosed-...-zygisk-release.zip (not the debug one, not riru).";
        if (mgr == 0) {
            st.add("Open Magisk > Settings and turn ON \"Zygisk\". Reboot.");
            st.add(zip);
            st.add("Magisk > Modules > Install from storage > choose that zip. Reboot.");
            st.add("After reboot open LSPosed from its notification, or tap the Action button on the LSPosed module in Magisk.");
        } else if (mgr == 1) {
            st.add("Open Kitsune Mask > Settings and turn ON \"Zygisk\". Reboot.");
            st.add(zip);
            st.add("Kitsune Mask > Modules > Install from storage > choose that zip. Reboot.");
            st.add("After reboot open LSPosed from its notification (or dial *#*#5776733#*#*).");
            st.add("Note: Kitsune Mask is no longer actively developed. If LSPosed does not work on your Android version, use official Magisk instead.");
        } else {
            String app = mgr == 2 ? "KernelSU" : "APatch";
            st.add(app + " has no built-in Zygisk. First install a Zygisk module: ReZygisk (github.com/PerformanC/ReZygisk) or ZygiskNext (github.com/Dr-TSNG/ZygiskNext), from " + app + " > Modules > Install. Reboot.");
            st.add(zip);
            st.add("Install the LSPosed zip the same way from " + app + " > Modules. Reboot.");
            st.add("After reboot open LSPosed from its notification, or from the Action button of the LSPosed module.");
        }
        st.add("Open Virtual Sound and allow \"Display over other apps\".");
        st.add("In LSPosed: Modules > Virtual Sound > turn ON > in scope tick Free Fire (and Free Fire MAX). Then force-stop the game.");
        st.add("Open the game, turn on voice chat and your mic.");
        st.add("Come back to Virtual Sound and minimize it with the top-right icon (or just press Home). A floating icon appears. Tap it, then tap any sound.");
        for (int i = 0; i < st.size(); i++) addT(b, (i + 1) + ". " + st.get(i), 14, SoundPanel.TXT, false, 10);

        addT(b, "Using the app", 16, SoundPanel.C2, true, 18);
        addT(b, "\u2022 PLAY/STOP: replays the last sound, or stops the current one.\n\u2022 Volume boost: raise it if teammates hear you too quietly.\n\u2022 Top-right folder icon: pick a whole folder of audio files.\n\u2022 Add sound: choose audio, a name and an optional picture.\n\u2022 Long-press a sound or folder to delete it.", 14, SoundPanel.TXT, false, 6);

        addT(b, "Not working?", 16, SoundPanel.C2, true, 18);
        addT(b, "Open LSPosed > Logs > Modules. If you see \"VirtualSound: loaded in ...\" the module is active. \"AudioRecord.read is being used\" means the game's mic was hooked. Your mic must be ON in the game when you tap a sound. You will not hear the sound yourself; teammates will.", 14, SoundPanel.TXT, false, 6);
        addT(b, "Warning: root and Xposed can get a game account banned. Try with a spare account first.", 13, SoundPanel.RED, false, 14);

        addB(b, "\u2190 Choose another root app", v -> helpAsk(b));
    }
}
