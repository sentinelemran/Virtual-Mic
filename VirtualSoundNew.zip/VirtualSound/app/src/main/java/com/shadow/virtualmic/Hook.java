package com.shadow.virtualmic;

import android.app.Application;
import android.content.*;
import android.media.AudioRecord;
import android.os.Build;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import de.robv.android.xposed.*;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class Hook implements IXposedHookLoadPackage {
    static final Object L = new Object();
    static short[] pcm;      // 16kHz mono
    static double pos;
    static float gain = 1f;
    static boolean registered, logged;

    public void handleLoadPackage(LoadPackageParam lp) {
        XposedBridge.log("VirtualSound: loaded in " + lp.packageName);
        XposedHelpers.findAndHookMethod(Application.class, "onCreate", new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam p) { reg((Context) p.thisObject); }
        });
        XposedBridge.hookAllMethods(AudioRecord.class, "read", new XC_MethodHook() {
            protected void afterHookedMethod(MethodHookParam p) {
                try { mix(p); } catch (Throwable t) { XposedBridge.log(t); }
            }
        });
    }

    static void reg(Context c) {
        synchronized (L) { if (registered) return; registered = true; }
        BroadcastReceiver r = new BroadcastReceiver() {
            public void onReceive(Context x, Intent i) {
                byte[] b = i.getByteArrayExtra("pcm");
                float g = i.getFloatExtra("gain", 1f);
                synchronized (L) {
                    if (b == null || b.length < 2) { pcm = null; return; }
                    short[] s = new short[b.length / 2];
                    ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(s);
                    pcm = s; pos = 0; gain = g;
                }
            }
        };
        IntentFilter f = new IntentFilter("com.shadow.virtualmic.PLAY");
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                Context.class.getMethod("registerReceiver", BroadcastReceiver.class, IntentFilter.class, int.class)
                        .invoke(c, r, f, 2); // RECEIVER_EXPORTED
            } else c.registerReceiver(r, f);
        } catch (Throwable t) { XposedBridge.log(t); }
    }

    static void mix(XC_MethodHook.MethodHookParam p) {
        Object res = p.getResult();
        if (!(res instanceof Integer)) return;
        int n = (Integer) res;
        if (n <= 0) return;
        if (!logged) { logged = true; XposedBridge.log("VirtualSound: AudioRecord.read is being used"); }
        Object b = p.args[0];
        AudioRecord ar = (AudioRecord) p.thisObject;
        int ch = Math.max(1, ar.getChannelCount());
        double step = 16000.0 / ar.getSampleRate();
        synchronized (L) {
            if (pcm == null) return;
            if (b instanceof short[]) {
                short[] a = (short[]) b;
                int off = (Integer) p.args[1];
                for (int i = 0; i + ch <= n; i += ch) {
                    int v = nxt(step);
                    if (v == Integer.MIN_VALUE) break;
                    for (int c = 0; c < ch; c++) a[off + i + c] = clip(a[off + i + c] + v);
                }
            } else if (b instanceof byte[]) {
                byte[] a = (byte[]) b;
                int off = (Integer) p.args[1];
                int ns = n / 2;
                for (int i = 0; i + ch <= ns; i += ch) {
                    int v = nxt(step);
                    if (v == Integer.MIN_VALUE) break;
                    for (int c = 0; c < ch; c++) {
                        int idx = off + (i + c) * 2;
                        int o = (short) ((a[idx] & 255) | (a[idx + 1] << 8));
                        int m = clip(o + v);
                        a[idx] = (byte) m;
                        a[idx + 1] = (byte) (m >> 8);
                    }
                }
            }
        }
    }

    static int nxt(double step) {
        int i = (int) pos;
        if (i >= pcm.length) { pcm = null; return Integer.MIN_VALUE; }
        int v = (int) (pcm[i] * gain);
        pos += step;
        return v;
    }

    static short clip(int x) { return (short) Math.max(-32768, Math.min(32767, x)); }
}
