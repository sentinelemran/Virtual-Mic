package com.shadow.virtualmic;

import android.app.AlertDialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Shared UI: boost, play/stop, sound grid, folders. Used in the app and in the floating window. */
public class SoundPanel extends LinearLayout {
    public interface Host { void addSound(); }

    static final int BG = 0xFF07070D, CARD = 0xFF12121E, BD = 0xFF25254A, C1 = 0xFF00F0FF,
            C2 = 0xFFFF2BD6, RED = 0xFFFF3B5C, MUT = 0xFF7D80A8, TXT = 0xFFEEF0FF;

    final Host host;
    final boolean editable;
    File folder;
    LinearLayout grid, folderBar;
    TextView boostVal, folderName;
    Button pb;
    final Runnable listener = new Runnable() { public void run() { updatePb(); } };

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    static GradientDrawable rect(Context c, int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(c, 1.5f), stroke);
        g.setCornerRadius(dp(c, r));
        return g;
    }

    static TextView tv(Context c, String s, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static class Tile extends LinearLayout {
        Tile(Context c) { super(c); }
        @Override protected void onMeasure(int w, int h) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(w), MeasureSpec.EXACTLY));
        }
    }

    public SoundPanel(final Context c, Host h, boolean ed) {
        super(c);
        host = h;
        editable = ed;
        setOrientation(VERTICAL);

        // boost card
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(VERTICAL);
        card.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 6));
        card.setBackground(rect(c, CARD, BD, 16));
        LinearLayout row = new LinearLayout(c);
        TextView l = tv(c, "Volume boost", 13, MUT);
        row.addView(l, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
        boostVal = tv(c, String.format("%.1fx", Player.gain), 15, C1);
        boostVal.setTypeface(null, Typeface.BOLD);
        row.addView(boostVal);
        card.addView(row);
        SeekBar sb = new SeekBar(c);
        sb.setMax(40);
        sb.setProgress(Math.round(Player.gain * 10));
        sb.setProgressTintList(ColorStateList.valueOf(C1));
        sb.setThumbTintList(ColorStateList.valueOf(C1));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                Player.gain = Math.max(0.1f, p / 10f);
                boostVal.setText(String.format("%.1fx", Player.gain));
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        card.addView(sb);
        Switch sw = new Switch(c);
        sw.setText("Hear sounds myself (test)");
        sw.setTextColor(MUT);
        sw.setTextSize(13);
        sw.setChecked(Player.preview);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton b, boolean on) { Player.preview = on; }
        });
        card.addView(sw);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        cl.bottomMargin = dp(c, 10);
        addView(card, cl);

        // play / stop
        pb = new Button(c);
        pb.setAllCaps(false);
        pb.setTextSize(15);
        pb.setTypeface(null, Typeface.BOLD);
        pb.setStateListAnimator(null);
        pb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (Player.playing) Player.stop(c);
                else if (Player.last != null && Player.last.pcm.exists()) Player.play(c, Player.last);
            }
        });
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(c, 48));
        pl.bottomMargin = dp(c, 10);
        addView(pb, pl);

        // folder bar
        folderBar = new LinearLayout(c);
        folderBar.setGravity(Gravity.CENTER_VERTICAL);
        folderBar.setVisibility(GONE);
        Button back = new Button(c);
        back.setAllCaps(false);
        back.setText("\u2190 Back");
        back.setTextColor(C1);
        back.setBackground(rect(c, 0, C1, 12));
        back.setStateListAnimator(null);
        back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { folder = null; refresh(); }
        });
        folderBar.addView(back, new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, dp(c, 40)));
        folderName = tv(c, "", 16, C2);
        folderName.setTypeface(null, Typeface.BOLD);
        folderName.setPadding(dp(c, 12), 0, 0, 0);
        folderBar.addView(folderName);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        fl.bottomMargin = dp(c, 8);
        addView(folderBar, fl);

        // grid
        ScrollView sv = new ScrollView(c);
        grid = new LinearLayout(c);
        grid.setOrientation(VERTICAL);
        if (ed) grid.setPadding(0, 0, 0, dp(c, 80));
        sv.addView(grid, new ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(sv, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1));

        updatePb();
        refresh();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Player.add(listener);
        updatePb();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Player.remove(listener);
    }

    void updatePb() {
        Context c = getContext();
        boolean p = Player.playing;
        pb.setText(p ? "\u25A0  STOP" : "\u25B6  PLAY");
        int col = p ? RED : C1;
        pb.setTextColor(col);
        pb.setBackground(rect(c, p ? 0x22FF3B5C : 0x1400F0FF, col, 14));
    }

    public void refresh() {
        Context c = getContext();
        grid.removeAllViews();
        List<View> tiles = new ArrayList<>();
        if (folder == null) {
            for (Store.Item it : Store.sounds(c, Store.soundsDir(c))) tiles.add(tile(it));
            for (Store.Item it : Store.folderItems(c)) tiles.add(tile(it));
            if (editable) tiles.add(addTile());
            folderBar.setVisibility(GONE);
        } else {
            for (Store.Item it : Store.sounds(c, folder)) tiles.add(tile(it));
            folderName.setText("\uD83D\uDCC1 " + folder.getName());
            folderBar.setVisibility(VISIBLE);
        }
        int m = dp(c, 4);
        LinearLayout row = null;
        for (int i = 0; i < tiles.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(c);
                grid.addView(row, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(m, m, m, m);
            row.addView(tiles.get(i), lp);
        }
        if (row != null) {
            for (int k = tiles.size() % 3; k > 0 && k < 3; k++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1);
                lp.setMargins(m, m, m, m);
                row.addView(new View(c), lp);
            }
        }
    }

    static String emoji(Store.Item it) {
        if (it.folder) return "\uD83D\uDCC1";
        switch (it.name) {
            case "Air Horn": return "\uD83D\uDCE2";
            case "Bruh": return "\uD83D\uDE10";
            case "Sad Horn": return "\uD83D\uDE22";
            case "Explosion": return "\uD83D\uDCA5";
            case "Laugh": return "\uD83D\uDE02";
            case "Drum": return "\uD83E\uDD41";
        }
        return "\uD83C\uDFB5";
    }

    Tile baseTile(String label, View icon) {
        final Context c = getContext();
        Tile t = new Tile(c);
        t.setOrientation(VERTICAL);
        t.setGravity(Gravity.CENTER);
        int p = dp(c, 6);
        t.setPadding(p, p, p, p);
        t.setBackground(rect(c, CARD, BD, 16));
        t.addView(icon);
        TextView n = tv(c, label, 12, TXT);
        n.setGravity(Gravity.CENTER);
        n.setMaxLines(2);
        n.setEllipsize(TextUtils.TruncateAt.END);
        n.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        nl.topMargin = dp(c, 4);
        t.addView(n, nl);
        return t;
    }

    View tile(final Store.Item it) {
        final Context c = getContext();
        View icon;
        if (it.icon != null) {
            ImageView iv = new ImageView(c);
            Bitmap b = BitmapFactory.decodeFile(it.icon.getPath());
            iv.setImageBitmap(b);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 38), dp(c, 38)));
            icon = iv;
        } else {
            TextView e = tv(c, emoji(it), 26, TXT);
            e.setGravity(Gravity.CENTER);
            icon = e;
        }
        final Tile t = baseTile(it.name, icon);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                flash(t);
                if (it.folder) { folder = it.dir; refresh(); }
                else Player.play(c, it);
            }
        });
        if (editable) {
            t.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    new AlertDialog.Builder(c).setTitle("Delete \"" + it.name + "\"?")
                            .setPositiveButton("Delete", new android.content.DialogInterface.OnClickListener() {
                                public void onClick(android.content.DialogInterface d, int w) { Store.delete(it); refresh(); }
                            }).setNegativeButton("Cancel", null).show();
                    return true;
                }
            });
        }
        return t;
    }

    View addTile() {
        final Context c = getContext();
        TextView plus = tv(c, "+", 30, C1);
        plus.setGravity(Gravity.CENTER);
        Tile t = baseTile("Add sound", plus);
        GradientDrawable g = rect(c, 0, 0xFF3A3A70, 16);
        g.setStroke(dp(c, 1.5f), 0xFF3A3A70, dp(c, 6), dp(c, 4));
        t.setBackground(g);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { if (host != null) host.addSound(); }
        });
        return t;
    }

    void flash(final View t) {
        final Context c = getContext();
        t.setBackground(rect(c, 0x3300F0FF, C1, 16));
        t.postDelayed(new Runnable() {
            public void run() { t.setBackground(rect(c, CARD, BD, 16)); }
        }, 300);
    }
}
