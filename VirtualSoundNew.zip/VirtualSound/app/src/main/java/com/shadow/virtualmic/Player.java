package com.shadow.virtualmic;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;

/** Sends PCM to the hook inside the game via broadcast and tracks play/stop state. */
public class Player {
    public static float gain = 1f;
    public static boolean playing;
    public static Store.Item last;
    static final Handler H = new Handler(Looper.getMainLooper());
    static final List<Runnable> LS = new ArrayList<>();
    static final Runnable END = new Runnable() {
        public void run() { playing = false; fire(); }
    };

    public static void add(Runnable r) { LS.add(r); }
    public static void remove(Runnable r) { LS.remove(r); }
    static void fire() { for (Runnable r : new ArrayList<>(LS)) r.run(); }

    public static void play(Context c, Store.Item it) {
        byte[] d = Store.read(it.pcm);
        if (d == null || d.length < 2) return;
        send(c, d);
        last = it;
        playing = true;
        H.removeCallbacks(END);
        H.postDelayed(END, d.length / 32 + 300);
        fire();
    }

    public static void stop(Context c) {
        send(c, null);
        playing = false;
        H.removeCallbacks(END);
        fire();
    }

    static void send(Context c, byte[] d) {
        Intent i = new Intent("com.shadow.virtualmic.PLAY");
        if (d != null) i.putExtra("pcm", d);
        i.putExtra("gain", gain);
        c.sendBroadcast(i);
    }
}
