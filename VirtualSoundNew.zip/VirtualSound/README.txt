Virtual Sound - package com.shadow.virtualmic (rooted phones, LSPosed)
Build with GitHub Actions (build.yml) or Android Studio.
